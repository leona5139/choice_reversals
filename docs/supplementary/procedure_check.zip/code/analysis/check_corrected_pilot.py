"""Validate and summarize a revised pilot without making API calls.

    python -m analysis.check_corrected_pilot output/results/pilot_3
    python -m analysis.check_corrected_pilot output/results/pilot_2 --allow-incomplete

Scripted control records require --allow-synthetic and are never presented as
model observations. All reported choices are explicitly confirmed choices.
"""
import argparse
import copy
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import zlib

from analysis.utils import classify_allocation
from prompt import prompt_b
from simulation.protocol import PROTOCOL_VERSION, ProtocolError, run_player
from simulation.treatments import TREATMENTS

ROOT = Path(__file__).resolve().parents[1]
REAL_PROVIDERS = {"gemini", "openrouter"}
SETUP_FIELDS = ("player_id", "run_name", "treatment", "provider", "model",
                "temperature", "prompt_version", "player_number", "seed")
GEMINI_RATES = {
    "gemini-3.1-flash-lite": {"input_per_million_usd": 0.25, "output_per_million_usd": 1.5},
    "gemini-3.5-flash-lite": {"input_per_million_usd": 0.3, "output_per_million_usd": 2.5},
}


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _json_normal(value):
    return json.loads(json.dumps(value, ensure_ascii=False))


def _read_jsonl(path):
    if not path.exists():
        return []
    values = []
    with path.open(encoding="utf-8") as f:
        for number, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except (ValueError, TypeError) as error:
                raise ValueError(f"{path.name}, line {number}: invalid JSON") from error
            _require(isinstance(value, dict), f"{path.name}, line {number}: expected an object")
            values.append(value)
    return values


def _positive_integer(value):
    return type(value) is int and value > 0


def _source_path(manifest, filename):
    if manifest.get("run_name") == "pilot_2" and manifest.get("evidence_kind") == "model_pilot":
        return ROOT / "simulation" / "archive" / (Path(filename).stem + "_pilot2.py")
    return ROOT / "simulation" / filename


def _bounded_settings(manifest, model_pairs):
    """Require the declared paid-pilot settings for the new Gemini-only runs."""
    if manifest["evidence_kind"] != "model_pilot" or not all(p == "gemini" for p, _ in model_pairs):
        return None
    settings = manifest.get("api_settings")
    _require(isinstance(settings, dict), "real Gemini pilot lacks its bounded API settings")
    expected = {"bounded_rest": True, "thinking_level": "MINIMAL", "max_output_tokens": 1024,
                "timeout_seconds": 60, "max_calls": 500, "max_reserved_usd": 2,
                "rates": GEMINI_RATES}
    if manifest["run_name"] != "pilot_2":
        expected["response_mime_type"] = "application/json"
    _require(settings == expected, "paid-pilot API settings differ from the declared limits and rates")
    _require(all(model in GEMINI_RATES for _, model in model_pairs), "model has no declared rate")
    path = _source_path(manifest, "gemini_bounded.py")
    _require(path.exists(), "bounded API client is missing")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    _require(manifest.get("client_sha256") == digest, "client_sha256 does not match the submitted client")
    return settings


def _expected_gemini_payload(messages, settings):
    contents = []
    system = []
    for message in messages:
        role, text = message.get("role"), message.get("content")
        _require(role in {"system", "user", "assistant"} and isinstance(text, str),
                 "invalid message in Gemini history")
        if role == "system":
            system.append(text)
            continue
        role = "model" if role == "assistant" else "user"
        if contents and contents[-1]["role"] == role:
            contents[-1]["parts"][0]["text"] += "\n\n" + text
        else:
            contents.append({"role": role, "parts": [{"text": text}]})
    payload = {"contents": contents, "generationConfig": {
        "temperature": 1.0, "candidateCount": 1,
        "maxOutputTokens": settings["max_output_tokens"],
        "thinkingConfig": {"thinkingLevel": settings["thinking_level"]},
    }}
    if "response_mime_type" in settings:
        payload["generationConfig"]["responseMimeType"] = settings["response_mime_type"]
    if system:
        payload["systemInstruction"] = {"parts": [{"text": system[-1]}]}
    return payload


def _validate_gemini_reply(value, request, setup, settings):
    """Check the exact REST inputs and provider result retained by the client."""
    _require(isinstance(value, dict), "bounded Gemini reply must be an object")
    _require(value.get("requested_model") == setup["model"], "transport used a different model")
    expected_payload = _expected_gemini_payload(request["messages"], settings)
    _require(value.get("request_payload") == expected_payload,
             "transport payload differs from the protocol history or generation settings")
    _require(value.get("status_code") == 200, "retained Gemini result lacks a successful HTTP status")
    _require(value.get("cost") is None, "Gemini does not return a verified dollar billing amount")
    raw = value.get("raw")
    _require(isinstance(raw, dict), "provider raw response is missing")
    usage = raw.get("usageMetadata", {})
    _require(isinstance(usage, dict) and value.get("usage") == usage, "usage summary differs from the provider response")
    for key in ("promptTokenCount", "candidatesTokenCount", "thoughtsTokenCount", "totalTokenCount", "cachedContentTokenCount"):
        if key in usage:
            _require(type(usage[key]) is int and usage[key] >= 0, f"invalid provider usage field {key}")
    version = raw.get("modelVersion")
    _require(value.get("model_version") == version, "model version differs from the provider response")
    candidates = raw.get("candidates", [])
    _require(isinstance(candidates, list), "provider candidates must be a list")
    candidate = candidates[0] if len(candidates) == 1 else {}
    _require(isinstance(candidate, dict), "provider candidate must be an object")
    finish = candidate.get("finishReason")
    _require(value.get("finish_reason") == finish, "finish reason differs from the provider response")
    parts = candidate.get("content", {}).get("parts", [])
    _require(isinstance(parts, list), "provider content parts must be a list")
    candidate_text = "".join(part.get("text", "") for part in parts
                             if isinstance(part, dict) and not part.get("thought", False)
                             and isinstance(part.get("text", ""), str))
    usable = len(candidates) == 1 and finish == "STOP"
    _require(value.get("text") == (candidate_text if usable else ""),
             "parsed response text differs from the provider's completed text")
    if "candidate_text" in value:
        _require(value["candidate_text"] == candidate_text, "stored candidate text differs from raw content")
    if request.get("error") is None:
        _require(usable, "a non-STOP provider response was accepted as a choice")
        _require(isinstance(version, str) and (version == setup["model"] or version.startswith(setup["model"] + "-")),
                 "provider modelVersion does not match the requested model")
        _require(all(type(usage.get(k)) is int and usage[k] > 0
                     for k in ("promptTokenCount", "candidatesTokenCount", "totalTokenCount")),
                 "accepted provider response has missing usage counts")
    if "totalTokenCount" in usage:
        _require(usage["totalTokenCount"] >= usage.get("promptTokenCount", 0)
                 + usage.get("candidatesTokenCount", 0), "provider usage totals are inconsistent")
    estimate = value.get("estimated_cost_usd")
    if all(k in usage for k in ("promptTokenCount", "candidatesTokenCount")):
        rates = settings["rates"][setup["model"]]
        output_tokens = max(usage["candidatesTokenCount"] + usage.get("thoughtsTokenCount", 0),
                            usage.get("totalTokenCount", usage["promptTokenCount"]) - usage["promptTokenCount"])
        expected = (usage["promptTokenCount"] * rates["input_per_million_usd"]
                    + output_tokens
                    * rates["output_per_million_usd"]) / 1_000_000
        _require(type(estimate) in (int, float) and math.isfinite(estimate)
                 and math.isclose(estimate, expected, rel_tol=1e-9, abs_tol=1e-12),
                 "reported cost estimate differs from provider usage and the declared rates")
    else:
        _require(estimate is None, "cost estimate is given without sufficient usage data")


def _decimal(value, label):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as error:
        raise ValueError(f"invalid {label}") from error
    _require(result.is_finite() and result >= 0, f"invalid {label}")
    return result


def _audit_budget(folder, manifest, records, failures):
    """Audit all reserved HTTP attempts, including interrupted participant runs."""
    settings = manifest.get("api_settings", {})
    if not settings.get("bounded_rest"):
        return {}
    path = folder / "budget_ledger.json"
    journal = _read_jsonl(folder / "callback_journal.jsonl")
    if not path.exists():
        _require(not records and not any(r.get("requests") for r in failures)
                 and not journal, "existing API evidence has no budget ledger")
        return {"reserved_http_attempts": 0, "reserved_cost_usd": 0.0,
                "returned_http_responses": 0, "estimated_usage_cost_usd": 0.0,
                "reservations_without_returned_response": 0,
                "journal_callbacks_started": 0, "journal_callbacks_returned": 0,
                "journal_callbacks_failed": 0, "journal_callbacks_unfinished": 0,
                "journal_participant_attempts": 0, "retained_partial_attempt_count": 0,
                "retained_partial_attempts": []}
    state = json.loads(path.read_text(encoding="utf-8"))
    _require(isinstance(state, dict) and state.get("schema_version") == 1,
             "invalid budget ledger schema")
    _require(state.get("max_calls") == settings["max_calls"]
             and _decimal(state.get("max_reserved_usd"), "budget limit") == Decimal(str(settings["max_reserved_usd"])),
             "ledger limits differ from the fixed plan")
    reservations = state.get("reservations")
    _require(isinstance(reservations, list) and len(reservations) <= settings["max_calls"],
             "invalid number of reserved HTTP attempts")
    cumulative = Decimal(0)
    for sequence, reservation in enumerate(reservations, 1):
        _require(isinstance(reservation, dict) and reservation.get("sequence") == sequence,
                 "budget reservation sequence is inconsistent")
        model = reservation.get("model")
        _require(model in settings["rates"], "reservation has no declared model rate")
        for key in ("input_utf8_bytes", "part_count", "input_token_estimate", "output_token_limit"):
            _require(type(reservation.get(key)) is int and reservation[key] >= 0,
                     f"invalid reservation field {key}")
        _require(reservation["input_utf8_bytes"] <= 131072 and reservation["part_count"] > 0,
                 "reservation exceeds the input limit or has no text parts")
        _require(reservation["input_token_estimate"] == reservation["input_utf8_bytes"]
                 + 64 * reservation["part_count"] + 2048, "input reservation calculation differs")
        _require(reservation["output_token_limit"] == settings["max_output_tokens"], "output reservation differs")
        rates = settings["rates"][model]
        input_rate = _decimal(reservation.get("input_per_million_usd"), "input rate")
        output_rate = _decimal(reservation.get("output_per_million_usd"), "output rate")
        _require(input_rate == Decimal(str(rates["input_per_million_usd"]))
                 and output_rate == Decimal(str(rates["output_per_million_usd"])), "reserved prices differ from plan")
        amount = (reservation["input_token_estimate"] * input_rate
                  + reservation["output_token_limit"] * output_rate) / Decimal(1_000_000)
        _require(_decimal(reservation.get("reserved_usd"), "reserved amount") == amount,
                 "reserved cost calculation differs")
        cumulative += amount
        _require(_decimal(reservation.get("cumulative_reserved_usd"), "cumulative reservation") == cumulative,
                 "cumulative budget reservation differs")
    _require(_decimal(state.get("reserved_usd"), "ledger total") == cumulative
             and cumulative <= Decimal(str(settings["max_reserved_usd"])), "ledger total exceeds or differs from plan")

    roster = {r["player_id"]: r for r in manifest["roster"]}
    starts, terminals, returns = {}, {}, {}
    for event in journal:
        _require(event.get("player_id") in roster and event.get("evidence_kind") == "model_pilot",
                 "API journal contains a participant or evidence kind outside this plan")
        attempt, callback = event.get("attempt_id"), event.get("callback")
        _require(isinstance(attempt, str) and bool(attempt) and _positive_integer(callback), "invalid journal identity")
        ident = (attempt, callback)
        kind = event.get("event")
        if kind == "started":
            _require(ident not in starts, "duplicate callback start in journal")
            starts[ident] = event
            continue
        _require(kind in {"returned", "failed"} and ident in starts and ident not in terminals,
                 "callback journal has an unmatched or duplicate terminal event")
        _require(event["player_id"] == starts[ident]["player_id"], "callback journal changed participant identity")
        terminals[ident] = event
        if kind != "returned":
            _require(isinstance(event.get("error_class"), str), "failed callback lacks its exception class")
            continue
        value = event.get("reply")
        setup = roster[event["player_id"]]
        request = {"messages": starts[ident].get("messages"), "error": "journal response before parsing"}
        _require(isinstance(request["messages"], list), "callback start lacks its sent history")
        _validate_gemini_reply(value, request, setup, settings)
        reservation = value.get("budget_reservation")
        _require(isinstance(reservation, dict) and _positive_integer(reservation.get("sequence")),
                 "returned response lacks a budget reservation")
        sequence = reservation["sequence"]
        _require(sequence <= len(reservations) and reservations[sequence - 1] == reservation,
                 "returned response reservation differs from the ledger")
        _require(sequence not in returns, "two returned callbacks share one HTTP reservation")
        parts = [p for c in value["request_payload"]["contents"] for p in c["parts"]]
        parts += value["request_payload"].get("systemInstruction", {}).get("parts", [])
        _require(reservation["model"] == setup["model"]
                 and reservation["part_count"] == len(parts)
                 and reservation["input_utf8_bytes"] == sum(len(p["text"].encode("utf-8")) for p in parts),
                 "reservation does not describe the actual HTTP payload")
        returns[sequence] = (value, request["messages"])

    observed = set()
    for record in records + failures:
        for request in record.get("requests", []):
            value = request.get("reply")
            if value is None:
                continue
            reservation = value.get("budget_reservation", {})
            sequence = reservation.get("sequence")
            _require(sequence in returns and sequence not in observed,
                     "recorded provider response has no unique journal return")
            _require(returns[sequence] == (value, request["messages"]),
                     "recorded response or sent history differs from the callback journal")
            observed.add(sequence)

    # Each journal attempt is a fresh participant conversation. A process can
    # stop before its engine record is saved, so retain and describe such an
    # attempt without inventing a failed participant record or an API outcome.
    journal_attempts = {}
    for (attempt, callback), start in starts.items():
        group = journal_attempts.setdefault(attempt, {"player_id": start["player_id"], "callbacks": {}})
        _require(group["player_id"] == start["player_id"], "one journal attempt contains multiple participants")
        group["callbacks"][callback] = (start, terminals.get((attempt, callback)))
    for group in journal_attempts.values():
        callbacks = group["callbacks"]
        _require(sorted(callbacks) == list(range(1, len(callbacks) + 1)),
                 "journal callback numbers are not consecutive within a participant attempt")

    def matches_attempt(record, group):
        requests = record.get("requests", [])
        if record["player_id"] != group["player_id"] or len(requests) != len(group["callbacks"]):
            return False
        for number, request in enumerate(requests, 1):
            start, terminal = group["callbacks"][number]
            if terminal is None or start.get("messages") != request.get("messages"):
                return False
            if request.get("reply") is not None:
                if terminal["event"] != "returned" or terminal.get("reply") != request["reply"]:
                    return False
            elif (terminal["event"] != "failed"
                  or request.get("error") != "provider error: " + terminal.get("error_class", "")):
                return False
        return True

    recorded_attempts = set()
    for record in records + failures:
        if not record.get("requests"):
            continue
        matching = [attempt for attempt, group in journal_attempts.items()
                    if attempt not in recorded_attempts and matches_attempt(record, group)]
        _require(bool(matching), "participant record does not match one complete callback-journal attempt")
        recorded_attempts.add(matching[0])
    partial_attempts = []
    for attempt, group in journal_attempts.items():
        if attempt in recorded_attempts:
            continue
        terminal_events = [terminal for _, terminal in group["callbacks"].values() if terminal is not None]
        partial_attempts.append({
            "attempt_id": attempt, "player_id": group["player_id"],
            "status": "journal_only",
            "callbacks_started": len(group["callbacks"]),
            "callbacks_returned": sum(event["event"] == "returned" for event in terminal_events),
            "callbacks_failed": sum(event["event"] == "failed" for event in terminal_events),
            "callbacks_unfinished": len(group["callbacks"]) - len(terminal_events),
        })
    estimates = [v[0].get("estimated_cost_usd") for v in returns.values()]
    return {"reserved_http_attempts": len(reservations), "reserved_cost_usd": float(cumulative),
            "returned_http_responses": len(returns),
            "estimated_usage_cost_usd": sum(e for e in estimates if e is not None),
            "responses_without_cost_estimate": sum(e is None for e in estimates),
            "reservations_without_returned_response": len(reservations) - len(returns),
            "callbacks_without_terminal_event": len(starts) - len(terminals),
            "returned_responses_outside_participant_records": len(returns) - len(observed),
            "journal_callbacks_started": len(starts),
            "journal_callbacks_returned": len(returns),
            "journal_callbacks_failed": sum(event["event"] == "failed" for event in terminals.values()),
            "journal_callbacks_unfinished": len(starts) - len(terminals),
            "journal_participant_attempts": len(journal_attempts),
            "retained_partial_attempt_count": len(partial_attempts),
            "retained_partial_attempts": partial_attempts,
            "partial_attempt_note": "Journal-only attempts are retained separately from saved participant records. They may be interrupted or still running; absent terminal events do not establish whether the provider completed or charged a call.",
            "budget_note": "Reservations and usage-based estimates are not provider billing amounts. Unreturned attempts may have unknown charges."}


def _manifest_roster(manifest, allow_synthetic):
    _require(isinstance(manifest, dict), "manifest must be an object")
    _require(manifest.get("schema_version") == 1, "unsupported manifest schema")
    _require(manifest.get("protocol_version") == PROTOCOL_VERSION, "wrong protocol version")
    kind = manifest.get("evidence_kind")
    _require(kind in {"model_pilot", "synthetic_control_test"}, "unknown evidence kind")
    _require(kind != "synthetic_control_test" or allow_synthetic,
             "scripted control records are not model evidence; use --allow-synthetic for an offline check")
    _require(type(manifest.get("temperature")) in (int, float) and manifest["temperature"] == 1.0,
             "the planned temperature must be 1.0")
    _require(manifest.get("conditions") == TREATMENTS, "manifest must contain all four conditions in the declared order")
    run_name = manifest.get("run_name")
    _require(isinstance(run_name, str) and run_name != "pilot_1"
             and run_name.replace("_", "").replace("-", "").isalnum(), "invalid or reserved run name")
    n = manifest.get("players_per_model_condition")
    _require(_positive_integer(n), "invalid number of participants per model and condition")
    for name in ("max_confirmations", "max_attempts"):
        _require(_positive_integer(manifest.get(name)), f"invalid {name}")
    rpm = manifest.get("requests_per_minute")
    _require(type(rpm) in (int, float) and math.isfinite(rpm) and rpm > 0, "invalid request rate")
    workers = manifest.get("workers", 1 if run_name == "pilot_2" and kind == "model_pilot" else None)
    _require(_positive_integer(workers) and workers <= 4, "manifest workers must be an integer from 1 to 4")
    if run_name == "pilot_2" and kind == "model_pilot":
        _require(workers == 1, "archived pilot_2 used one worker")
    models = manifest.get("models")
    _require(isinstance(models, list) and len(models) >= 2, "at least two model entries are required")
    model_pairs = []
    for model in models:
        _require(isinstance(model, dict) and set(model) == {"provider", "model"}, "invalid model entry")
        provider, name = model["provider"], model["model"]
        _require(isinstance(name, str) and bool(name), "empty model identifier")
        allowed = {"scripted"} if kind == "synthetic_control_test" else REAL_PROVIDERS
        _require(provider in allowed, "provider is inconsistent with the evidence kind")
        model_pairs.append((provider, name))
    _require(len(set(model_pairs)) == len(model_pairs), "duplicate model entry")
    _require(len({name for _, name in model_pairs}) >= 2, "at least two distinct model identifiers are required")
    _require(manifest.get("draw_policy") == "independent uniform ticket from 1 to 20 in each round; one uniform payment round",
             "manifest draw policy differs from this protocol")
    _bounded_settings(manifest, model_pairs)

    expected = []
    for provider, model in model_pairs:
        for treatment in TREATMENTS:
            for number in range(n):
                expected.append({
                    "player_id": f"{treatment}|{provider}|{model}|t=1.0|{prompt_b.PROMPT_VERSION}|{number}",
                    "run_name": run_name, "treatment": treatment, "provider": provider,
                    "model": model, "temperature": 1.0, "prompt_version": prompt_b.PROMPT_VERSION,
                    "player_number": number,
                    "seed": zlib.crc32(f"{run_name}|{treatment}|{number}".encode()),
                })
    _require(manifest.get("planned_participants") == len(expected), "planned participant count does not match the design")
    _require(manifest.get("roster") == expected, "roster differs from the declared fixed plan")
    for key, path in (
        ("protocol_sha256", ROOT / "simulation" / "protocol.py"),
        ("prompt_sha256", ROOT / "prompt" / "prompt_b.py"),
        ("runner_sha256", _source_path(manifest, "run_corrected.py")),
    ):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        _require(manifest.get(key) == digest, f"{key} does not match the submitted source")
    return expected


def _replay(record, manifest, setup, failed=False):
    for key in SETUP_FIELDS:
        _require(type(record.get(key)) is type(setup[key]) and record[key] == setup[key],
                 f"{setup['player_id']}: metadata mismatch in {key}")
    _require(record.get("evidence_kind") == manifest["evidence_kind"], "record evidence kind differs from its manifest")
    _require(record.get("protocol_version") == PROTOCOL_VERSION, "record protocol version differs")
    _require(record.get("status") == ("failed" if failed else "completed"), "record has the wrong completion status")
    requests = record.get("requests")
    _require(isinstance(requests, list), "request history is missing")
    if failed and record.get("failure_stage") == "provider_initialization":
        _require(not requests and not record.get("rounds"), "initialization failure contains experiment choices")
        _require(record.get("cost") == 0.0 and record.get("cost_unknown_requests") == 0,
                 "initialization failure contains unrecorded requests or costs")
        _require(isinstance(record.get("error"), str) and bool(record["error"]), "initialization failure lacks an error")
        return
    _require(bool(requests), "participant has no recorded requests")
    consumed = 0

    def reply(messages):
        nonlocal consumed
        _require(consumed < len(requests), "replay needed an unrecorded reply")
        request = requests[consumed]
        _require(isinstance(request, dict) and request.get("index") == consumed, "request indices are inconsistent")
        _require(request.get("messages") == messages, f"request {consumed}: sent history differs from protocol")
        consumed += 1
        value = request.get("reply")
        if value is None:
            error = request.get("error", "")
            match = re.fullmatch(r"provider error: ([A-Za-z_][A-Za-z_0-9]*)", error)
            _require(match is not None, "missing provider reply without a recorded provider error")
            raise type(match.group(1), (Exception,), {})()
        if manifest["evidence_kind"] == "model_pilot":
            _require(not (isinstance(value, dict) and value.get("source") == "scripted_control"),
                     "a scripted reply has been labelled as model evidence")
            if setup["provider"] == "gemini" and manifest.get("api_settings", {}).get("bounded_rest"):
                _validate_gemini_reply(value, request, setup, manifest["api_settings"])
        return copy.deepcopy(value)

    try:
        reproduced = run_player(setup["treatment"], prompt_b, setup["seed"], reply,
                                max_confirmations=manifest["max_confirmations"],
                                max_attempts=manifest["max_attempts"])
    except ProtocolError as error:
        _require(failed, f"completed record fails protocol replay: {error}")
        reproduced = error.record
    else:
        _require(not failed, "failed record replays as a completed participant")
    _require(consumed == len(requests), "record contains unused or extra requests")
    reproduced = _json_normal(reproduced)
    for key, value in reproduced.items():
        _require(record.get(key) == value, f"{setup['player_id']}: replay mismatch in {key}")


def _round_rows(records):
    rows = []
    for record in records:
        for number in range(1, 9):
            r = record["rounds"][str(number)]
            initial = r["initial"] or {}
            revision = r["revision"] or {}
            final = revision or initial
            eligible = r["task"] == "AR" and r["draw"]["group"] == "participant"
            row = {key: record[key] for key in SETUP_FIELDS}
            row.update({
                "evidence_kind": record["evidence_kind"], "round": number,
                "task": r["task"], "computer_a": r["computer"]["A"],
                "computer_b": r["computer"]["B"], "draw_group": r["draw"]["group"],
                "ticket": r["draw"]["ticket"], "winning_household": r["winner"],
                "eligible_revision": eligible,
                "changed_after_reveal": bool(eligible and revision != initial),
            })
            for label, choice in (("initial", initial), ("revision", revision), ("final", final)):
                row[label + "_a"] = choice.get("A")
                row[label + "_b"] = choice.get("B")
                row[label + "_category"] = (classify_allocation(r["computer"]["A"], choice["A"])
                                            if choice else None)
            for stage in ("initial", "revision"):
                edits = [c for c in record["confirmations"] if c["round"] == number
                         and c["stage"] == stage and c["response"]["confirm"] is False]
                row[stage + "_confirmation_changes"] = sum(
                    c["candidate"] != {k: c["response"][k] for k in ("A", "B")} for c in edits)
            rows.append(row)
    return rows


def _rates(rows):
    eligible = [r for r in rows if r["eligible_revision"]]
    changed = sum(r["changed_after_reveal"] for r in eligible)
    return {"round_records": len(rows), "eligible_revisions": len(eligible),
            "changed_after_reveal": changed,
            "reversal_rate": changed / len(eligible) if eligible else None,
            "initial_confirmation_changes": sum(r["initial_confirmation_changes"] for r in rows),
            "revision_confirmation_changes": sum(r["revision_confirmation_changes"] for r in rows),
            "initial_A_choices": sum(r["task"] == "A" and r["initial_a"] is not None for r in rows),
            "initial_P_choices": sum(r["task"] == "P" and r["initial_a"] is not None for r in rows)}


def _example_requests(records):
    # records follows the fixed manifest roster. Selection is based on model,
    # round eligibility and request order, never the allocation or reversal.
    model_order = list(dict.fromkeys((r["provider"], r["model"]) for r in records))
    _require(len(model_order) >= 2, "examples require both of the first two planned models")
    first = [r for r in records if (r["provider"], r["model"]) == model_order[0]]
    second = [r for r in records if (r["provider"], r["model"]) == model_order[1]]

    def first_eligible(group):
        for record in group:
            for number in range(5, 9):
                if record["rounds"][str(number)]["revision"] is not None:
                    return record, number
        return None

    def accepted(record, number, phase):
        requests = [r for r in record["requests"] if r["round"] == number
                    and r["phase"] == phase and r["error"] is None]
        _require(bool(requests), "eligible round lacks a required accepted request")
        return record, requests[0]

    eligible = first_eligible(first)
    if eligible is not None:
        record, number = eligible
        selected = [accepted(record, number, phase) for phase in
                    ("initial_allocation", "initial_confirmation", "revision_allocation")]
    else:
        # Preserve an independently drawn run with no eligible AR round. Never
        # add participants or rerun to manufacture a desired example.
        selected, seen_questions = [], set()
        for record in first:
            for request in record["requests"]:
                question = request["messages"][-1]["content"]
                if request["error"] is None and question not in seen_questions:
                    selected.append((record, request))
                    seen_questions.add(question)
                    if len(selected) == 3:
                        break
            if len(selected) == 3:
                break
        _require(len(selected) == 3, "first model lacks three accepted example questions")
    eligible = first_eligible(second)
    if eligible is not None:
        record, number = eligible
        selected.append(accepted(record, number, "revision_confirmation"))
    else:
        candidates = [(record, request) for record in second for request in record["requests"]
                      if request["phase"] == "initial_confirmation" and request["error"] is None]
        _require(bool(candidates), "second model lacks an accepted confirmation example")
        selected.append(candidates[0])
    return selected


def _write_outputs(folder, manifest, records, failures, rows, summary):
    complete = summary["status"] == "verified_complete"
    name = "summary" if complete else "partial_summary"
    (folder / (name + ".json")).write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if complete:
        with (folder / "rounds.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    kind = summary["evidence_kind"]
    heading = "Offline protocol control check" if kind == "synthetic_control_test" else "Revised pilot observations"
    lines = [heading, "", f"Validation status: {summary['status']}.", f"Evidence kind: {kind}.", ""]
    if not complete:
        lines += ["The fixed sample plan is incomplete. The counts below describe completed participants only and do not establish a complete, balanced pilot. Failed and journal-only attempts remain separate, with their full raw evidence retained.", ""]
    if kind == "synthetic_control_test":
        lines += ["All replies are generated by a fixed scripted controller. These counts are software checks, not LLM or human behavior.", ""]
    lines += [f"Completed participants: {summary['completed_participants']} of {summary['planned_participants']}.",
              f"Eligible post-reveal choices: {summary['eligible_revisions']}.",
              f"Changes between confirmed initial and confirmed post-reveal choices: {summary['changed_after_reveal']}.",
              f"Initial confirmation edits are counted separately: {summary['initial_confirmation_changes']}.",
              f"Recorded failed participant attempts, including later successful retries: {summary['failed_participant_attempts']}.",
              f"Application requests in completed participant records: {summary['completed_record_requests']}.",
              f"Application requests in normally failed participant records: {summary['failed_record_requests']}.",
              f"Recorded application requests across completed and failed attempts: {summary['application_requests']}.",
              f"Provider-reported known cost: {summary['known_cost']:.6f}; requests without a known cost: {summary['cost_unknown_requests']}.",
              ("Direct REST calls use no SDK-internal retry loop." if manifest.get("api_settings", {}).get("bounded_rest")
               else "SDK-internal network retries are not separately visible in these application request logs."), "",
              "The sample plan and exact source hashes are in manifest.json. Raw replies and exact input histories are retained in players.jsonl and failures.jsonl.",
              "The original pilot is a separate dataset and is not combined with these counts.", "",
              "| Model | Condition | Participants | Eligible revisions | Changes |",
              "|---|---|---:|---:|---:|"]
    for cell in summary["by_model_condition"]:
        lines.append(f"| {cell['provider']}/{cell['model']} | {cell['treatment']} | {cell['participants']} | {cell['eligible_revisions']} | {cell['changed_after_reveal']} |")
    lines += ["", "Reversal rates use eligible post-reveal opportunities. Decisions within a participant share history and are not independent observations."]
    if "reserved_http_attempts" in summary:
        lines += ["", f"Reserved HTTP attempts: {summary['reserved_http_attempts']}.",
                  f"Cumulative conservative reservation: ${summary['reserved_cost_usd']:.6f}.",
                  f"Estimate from returned usage counts and declared rates: ${summary['estimated_usage_cost_usd']:.6f}.",
                  f"Reservations without a returned provider response: {summary['reservations_without_returned_response']}.",
                  f"Returned responses outside normal participant records: {summary.get('returned_responses_outside_participant_records', 0)}.",
                  f"Journal callbacks across every attempt: {summary['journal_callbacks_started']} started, {summary['journal_callbacks_returned']} returned, {summary['journal_callbacks_failed']} failed, {summary['journal_callbacks_unfinished']} without a terminal event.",
                  f"Participant attempts retained only in the journal: {summary['retained_partial_attempt_count']}.",
                  "Reservations and usage estimates are separate from provider billing. Interrupted or unreturned attempts can have unknown charges."]
        for partial in summary["retained_partial_attempts"]:
            lines.append(f"Journal-only attempt {partial['attempt_id']} for {partial['player_id']}: {partial['callbacks_started']} callbacks started, {partial['callbacks_returned']} returned, {partial['callbacks_failed']} failed, {partial['callbacks_unfinished']} unfinished. It is not included in behavioral results.")
    (folder / (name + ".md")).write_text("\n".join(lines) + "\n", encoding="utf-8")
    if kind == "model_pilot" and complete:
        examples = ["Recorded examples from the revised model pilot", "",
                    "Selection follows the fixed model and participant order. Examples 1-3 use the first eligible AR round for the first model, taking its first accepted initial-allocation, initial-confirmation and revision-allocation requests. Example 4 uses the first accepted revision-confirmation request from the first eligible AR round for the second model.",
                    "If the first model has no eligible AR round, examples 1-3 use its first three distinct accepted questions. If the second model has no eligible AR round, example 4 uses its first accepted initial-confirmation request. Selection does not depend on allocations or whether a reversal occurred.",
                    "Accepted here means that the reply passed its requested JSON schema; a confirmation reply may ask to revise. Final choices are the separately stored explicitly confirmed allocations.",
                    "Each excerpt contains the final user question and exact raw reply. Complete histories are in the identified player's request record.", ""]
        for number, (record, request) in enumerate(_example_requests(records), 1):
            examples += [f"Example {number}", f"Player ID: {record['player_id']}",
                         f"Request index: {request['index']}; round: {request['round']}; phase: {request['phase']}",
                         "QUESTION", request["messages"][-1]["content"], "RAW REPLY", request["reply"]["text"], ""]
        (folder / "response_examples.txt").write_text("\n".join(examples), encoding="utf-8")


def validate_run(folder, allow_synthetic=False, require_complete=True, write_outputs=True):
    """Replay saved records and write complete or explicitly partial summaries.

    This verifies saved records and their relation to submitted code. It cannot
    independently attest that an external provider produced a stored response.
    """
    folder = Path(folder)
    try:
        manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    except (ValueError, TypeError) as error:
        raise ValueError("invalid manifest JSON") from error
    roster = _manifest_roster(manifest, allow_synthetic)
    records = _read_jsonl(folder / "players.jsonl")
    failures = _read_jsonl(folder / "failures.jsonl")
    by_id = {r.get("player_id"): r for r in records}
    _require(len(by_id) == len(records), "duplicate completed participant IDs")
    expected = {r["player_id"]: r for r in roster}
    _require(set(by_id).issubset(expected), "completed records are outside the fixed plan")
    complete = set(by_id) == set(expected)
    _require(complete or not require_complete,
             f"fixed plan is incomplete: expected {len(expected)}, found {len(records)}")
    records = [by_id[setup["player_id"]] for setup in roster if setup["player_id"] in by_id]
    for record in records:
        _replay(record, manifest, expected[record["player_id"]])
    for failure in failures:
        ident = failure.get("player_id")
        _require(ident in expected, "failure record is outside the fixed plan")
        _replay(failure, manifest, expected[ident], failed=True)
    budget_summary = _audit_budget(folder, manifest, records, failures)
    rows = _round_rows(records)
    cells = []
    for model in manifest["models"]:
        for treatment in TREATMENTS:
            group = [row for row in rows if row["provider"] == model["provider"]
                     and row["model"] == model["model"] and row["treatment"] == treatment]
            cells.append({**model, "treatment": treatment,
                          "participants": len({r["player_id"] for r in group}), **_rates(group)})
    attempts = records + failures
    summary = {"schema_version": 1, "status": "verified_complete" if complete else "verified_partial",
               "evidence_kind": manifest["evidence_kind"], "protocol_version": PROTOCOL_VERSION,
               "run_name": manifest["run_name"], "planned_participants": len(roster),
               "workers": manifest.get("workers", 1),
               "completed_participants": len(records), "failed_participant_attempts": len(failures),
               "completed_record_requests": sum(len(r["requests"]) for r in records),
               "failed_record_requests": sum(len(r["requests"]) for r in failures),
               "application_requests": sum(len(r["requests"]) for r in attempts),
               "invalid_reply_attempts": sum(q.get("reply") is not None and q.get("error") is not None
                                             for r in attempts for q in r["requests"]),
               "provider_error_attempts": sum(q.get("reply") is None for r in attempts for q in r["requests"]),
               "known_cost": sum(r["cost"] for r in attempts),
               "cost_unknown_requests": sum(r["cost_unknown_requests"] for r in attempts),
               "cost_note": "Known provider-reported amounts only; not an invoice or estimate of unknown charges.",
               **_rates(rows), "by_model_condition": cells, **budget_summary}
    if write_outputs:
        _write_outputs(folder, manifest, records, failures, rows, summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--allow-synthetic", action="store_true")
    parser.add_argument("--allow-incomplete", action="store_true",
                        help="audit partial evidence and write partial_summary files; does not pass the complete-pilot requirement")
    args = parser.parse_args(argv)
    try:
        result = validate_run(args.folder, allow_synthetic=args.allow_synthetic,
                              require_complete=not args.allow_incomplete)
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1
    label = "PASS" if result["status"] == "verified_complete" else "PARTIAL AUDIT PASS (fixed sample incomplete)"
    print(f"{label}: {result['completed_participants']}/{result['planned_participants']} participants; {result['eligible_revisions']} eligible revisions; evidence_kind={result['evidence_kind']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
