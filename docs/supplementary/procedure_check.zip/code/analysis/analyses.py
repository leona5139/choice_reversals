"""Overview and the initial-choice comparisons in Figures 1 and 2."""
from collections import Counter

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
from matplotlib.ticker import FuncFormatter, MultipleLocator

from analysis.utils import CATEGORIES, SETUP_FIELDS, group_rows, player_key, write_csv
from simulation.treatments import tasks_in

FIGURE_DPI = 320
# Every label is two lines so a short name stays on the first line, beside its neighbors.
LABELS = ["Over-\ncompensating", "Ex ante\nequalizing", "Mixed\n", "Ex post\nequalizing", "Reinforcing\n"]
CHOICE_FIELDS = ("treatment", "period", "category", "consistency",
                 "count", "percent", "n_players", "n_respondents", "n_choices")


def setup_label(setup):
    provider, model, temperature, prompt_version = setup
    return f"{provider} / {model} | t={temperature} | {prompt_version}"


def overview(rows, folder):
    table = []
    fields = (*SETUP_FIELDS, "treatment", "task")
    for key, group in group_rows(rows, fields).items():
        choices = [r for r in group if r["initial_a"] is not None]
        categories = Counter(r["initial_category"] for r in choices)
        record = dict(zip(fields, key))
        record.update({
            "n_players": len({player_key(r) for r in group}),
            "n_rounds": len(group),
            "initial_choices": len(choices),
            "skipped_initial_choices": len(group) - len(choices),
            "revision_opportunities": sum(r["revision_offered"] for r in group),
            "changed_choices": sum(r["changed"] is True for r in group),
            "changes_to_5_5": sum(r["changed"] is True and r["revision_a"] == 5 for r in group),
        })
        record.update({f"initial_{category}": categories[category] for category in CATEGORIES})
        table.append(record)
        print(f"{setup_label(key[:4])} | {key[4]} {key[5]}: "
              f"{len(choices)}/{len(group)} initial choices; "
              f"{record['changed_choices']}/{record['revision_opportunities']} revisions changed")
    return [write_csv(folder / "00_overview.csv", table)]


def choice_distribution(rows, with_consistency=False, by=()):
    """Groups by treatment and period. Pass by=("model", "temperature") to split further."""
    table = []
    fields = (*by, "treatment", "period")
    for key, group in group_rows(rows, fields).items():
        choices = [r for r in group if r["initial_a"] is not None]
        per_player = {}
        for row in choices:
            per_player.setdefault(player_key(row), Counter())[row["initial_category"]] += 1
        counts = Counter()
        for row in choices:
            category = row["initial_category"]
            own = per_player[player_key(row)]
            consistency = own[category] / own.total() if with_consistency else None
            counts[category, consistency] += 1
        levels = sorted({level for _, level in counts if level is not None}) or [None]
        for category in CATEGORIES:
            for consistency in levels:
                count = counts[category, consistency]
                table.append({
                    **dict(zip(fields, key)),
                    "category": category,
                    "consistency": consistency,
                    "count": count,
                    "percent": 100 * count / len(choices) if choices else None,
                    "n_players": len({player_key(r) for r in group}),
                    "n_respondents": len(per_player),
                    "n_choices": len(choices),
                })
    return table


def draw_panel(ax, records, title, levels=None, frame="A"):
    ax.set_title(title, fontsize=11)
    ax.set_xticks(range(5))
    ax.set_xticklabels(LABELS, fontsize=9)
    for label in ax.get_xticklabels():
        label.set_verticalalignment("top")
    ax.set_ylim(0, 100)
    ax.set_ylabel("Choices (%)", fontsize=9)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="0.88", linewidth=0.6)
    ax.set_facecolor("0.94" if frame == "P" else "white")
    if not records or records[0]["n_choices"] == 0:
        ax.text(0.5, 0.5, "No observed choices", ha="center", transform=ax.transAxes)
        return
    bottom = [0.0] * 5
    for level in levels or [None]:
        heights = [sum(r["percent"] for r in records
                       if r["category"] == category and r["consistency"] == level)
                   for category in CATEGORIES]
        color = plt.cm.Greys(0.25 + 0.65 * level) if level is not None else "0.3"
        ax.bar(range(5), heights, bottom=bottom, color=color, edgecolor="white", linewidth=0.4)
        bottom = [a + b for a, b in zip(bottom, heights)]


FIG1_TREATMENTS = ("4A_4AR", "4P_4AR")


def save_paper_figure(png, panels, figsize, top, legend_position):
    """Use the panel layout and frequency scale of the published figures."""
    levels = sorted({0.25, 0.5, 0.75, 1.0} | {
        r["consistency"] for _, records in panels for r in records if r["consistency"] is not None
    })
    handles = [Patch(color=plt.cm.Greys(0.25 + 0.65 * level), label=f"{level:g}") for level in levels]
    labels = [category.replace("_", " ").title() for category in CATEGORIES]
    font = 12 if len(panels) == 2 else 14
    fig, axes = plt.subplots(1, len(panels), figsize=figsize, sharey=True)
    fig.subplots_adjust(left=0.07 if len(panels) == 2 else 0.06, right=0.992,
                        bottom=0.34, top=0.92, wspace=0.025)
    for ax, (title, records) in zip(axes, panels):
        draw_panel(ax, records, "", levels[::-1])
        ax.grid(False)
        ax.set_ylabel("")
        ax.set_xticks(range(len(labels)), labels, rotation=-90, fontsize=font)
        ax.tick_params(axis="y", labelsize=font)
        ax.add_patch(Rectangle((0, 1), 1, 0.11, transform=ax.transAxes, clip_on=False,
                               facecolor="0.81", edgecolor="black"))
        ax.text(0.5, 1.055, title, ha="center", va="center", transform=ax.transAxes, fontsize=font)
        ax.legend(handles=handles, title="Consistency", loc=legend_position, frameon=False,
                  fontsize=font - 1, title_fontsize=font, labelspacing=0.15, handlelength=1)
    highest_bar = max(ax.dataLim.ymax for ax in axes)
    axes[0].set_ylim(0, max(top, highest_bar * 1.05))
    axes[0].yaxis.set_major_locator(MultipleLocator(20))
    axes[0].yaxis.set_major_formatter(FuncFormatter(lambda percent, _: f"{percent / 100:.1f}"))
    axes[0].set_ylabel("Frequency", fontsize=font)
    fig.supxlabel("Choice category", y=0.015, fontsize=font)
    fig.savefig(png, dpi=FIGURE_DPI)
    plt.close(fig)


def figure_1_choices(rows, by=()):
    selected = [{**r, "period": "1-4"} for r in rows
                if r["treatment"] in FIG1_TREATMENTS and r["round"] <= 4]
    return choice_distribution(selected, with_consistency=True, by=by)


def save_figure_1(table, png, suptitle, by=()):
    if not by:
        panels = [(title, [r for r in table if r["treatment"] == treatment])
                  for title, treatment in zip(("Panel A: Ex Ante Frame", "Panel B: Ex Post Frame"), FIG1_TREATMENTS)]
        save_paper_figure(png, panels, (11, 6.4), 67, "upper right")
        return
    levels = sorted({r["consistency"] for r in table if r["consistency"] is not None})
    groups = group_rows(table, by)
    fig, axes = plt.subplots(len(groups), 2, figsize=(11, 2.8 * len(groups)), squeeze=False)
    fig.suptitle(suptitle, fontsize=14)
    for index, (key, group) in enumerate(groups.items()):
        for col, treatment in enumerate(FIG1_TREATMENTS):
            records = [r for r in group if r["treatment"] == treatment]
            n = records[0]["n_choices"] if records else 0
            title = f"{treatment} | {n} choices"
            model, temperature = key
            title = f"{model} | t={temperature}\n{title}"
            draw_panel(axes[index, col], records, title, levels, frame="A" if col == 0 else "P")
    handles = [Patch(facecolor=plt.cm.Greys(0.25 + 0.65 * level), label=f"{level:.0%}") for level in levels]
    fig.legend(handles=handles, title="Consistency within rounds 1–4", loc="lower center", ncol=4)
    fig.tight_layout(rect=(0, 0.14 / len(groups), 1, 1 - 0.08 / len(groups)))
    fig.savefig(png, dpi=FIGURE_DPI)
    plt.close(fig)


def figure_1(rows, folder):
    table = figure_1_choices(rows)
    files = [write_csv(folder / "01_fig1_choices.csv", table, CHOICE_FIELDS)]
    png = folder / "01_fig1_choices.png"
    if not table:
        png.unlink(missing_ok=True)
        print("Figure 1: no data for 4A_4AR or 4P_4AR.")
        return files
    save_figure_1(table, png, "Figure 1: Initial choices in rounds 1–4")
    return files + [png]


def figure_1_by_model(rows, folder):
    by = ("model", "temperature")
    table = figure_1_choices(rows, by)
    files = [write_csv(folder / "04_fig1_by_model.csv", table, (*by, *CHOICE_FIELDS))]
    png = folder / "04_fig1_by_model.png"
    if not table:
        png.unlink(missing_ok=True)
        print("Figure 1 by model: no data for 4A_4AR or 4P_4AR.")
        return files
    save_figure_1(table, png, "Figure 1 by model and temperature: initial choices in rounds 1–4", by)
    return files + [png]


def marginal_distribution(rows, category_field):
    """Same five-category bars as Figure 1, for one already-selected set of rounds."""
    choices = [r for r in rows if r.get(category_field) is not None]
    per_player = {}
    for row in choices:
        per_player.setdefault(player_key(row), Counter())[row[category_field]] += 1
    counts = Counter()
    for row in choices:
        category = row[category_field]
        own = per_player[player_key(row)]
        counts[category, own[category] / own.total()] += 1
    levels = sorted({level for _, level in counts}) or [None]
    table = []
    for category in CATEGORIES:
        for consistency in levels:
            count = counts[category, consistency]
            table.append({
                "category": category,
                "consistency": consistency,
                "count": count,
                "percent": 100 * count / len(choices) if choices else None,
                "n_players": len({player_key(r) for r in rows}),
                "n_respondents": len(per_player),
                "n_choices": len(choices),
            })
    return table


FIG3_PANELS = (
    ("initial", "initial_category", "Initial"),
    ("final", "final_category", "Final"),
    ("changes", "final_category", "Final (changes only)"),
)
FIG3_FIELDS = ("panel", "category", "consistency", "count", "percent",
               "n_players", "n_respondents", "n_choices")


def figure_3(rows, folder, by_model=False):
    """Original and final choices in rounds 5–8 of 4A_4AR."""
    selected = [r for r in rows if r["treatment"] == "4A_4AR" and 5 <= r["round"] <= 8]
    by = ("model", "temperature") if by_model else ()
    groups = group_rows(selected, by) if by else {(): selected}
    table = []
    for setup, group in groups.items():
        for panel, field, _title in FIG3_PANELS:
            source = [r for r in group if r["changed"] is True] if panel == "changes" else group
            table.extend({**dict(zip(by, setup)), "panel": panel, **record}
                         for record in marginal_distribution(source, field))
    stem = "05_fig3_by_model" if by_model else "03_fig3_revisions"
    files = [write_csv(folder / f"{stem}.csv", table, (*by, *FIG3_FIELDS))]
    png = folder / f"{stem}.png"
    if not selected:
        png.unlink(missing_ok=True)
        print("Figure 3: no rounds 5–8 for 4A_4AR.")
        return files
    if not by_model:
        panels = [(title, [r for r in table if r["panel"] == panel]) for panel, _, title in FIG3_PANELS]
        save_paper_figure(png, panels, (15, 7.5), 86, "upper left")
        return files + [png]
    levels = sorted({r["consistency"] for r in table if r["consistency"] is not None})
    fig, axes = plt.subplots(len(groups), 3, figsize=(15, 2.8 * len(groups)), squeeze=False)
    fig.suptitle("Figure 3 by model and temperature: Original and final choices in rounds 5–8 of 4A_4AR", fontsize=14)
    for row, (setup, group) in enumerate(group_rows(table, by).items()):
        for col, (panel, _field, title) in enumerate(FIG3_PANELS):
            records = [r for r in group if r["panel"] == panel]
            title = f"{setup[0]} | t={setup[1]}\n{title}"
            draw_panel(axes[row, col], records, f"{title}\n{records[0]['n_choices']} choices", levels)
    handles = [Patch(facecolor=plt.cm.Greys(0.25 + 0.65 * level), label=f"{level:.0%}") for level in levels]
    fig.legend(handles=handles, title="Consistency within the panel", loc="lower center", ncol=4)
    fig.tight_layout(rect=(0, 0.14 / len(groups), 1, 1 - 0.08 / len(groups)))
    fig.savefig(png, dpi=FIGURE_DPI)
    plt.close(fig)
    return files + [png]


def figure_3_by_model(rows, folder):
    return figure_3(rows, folder, by_model=True)


def figure_2(rows, folder):
    treatments = ("2A2P_4AR", "2P2A_4AR", "4A_4AR", "4P_4AR")
    periods = ("1-2", "3-4", "5-8")
    selected = [r for r in rows if r["treatment"] in treatments]
    table = choice_distribution(selected)
    files = [write_csv(folder / "02_fig2_choices.csv", table, CHOICE_FIELDS)]
    png = folder / "02_fig2_choices.png"
    if not table:
        png.unlink(missing_ok=True)
        print("Figure 2: no data for the four main treatments.")
        return files
    fig, axes = plt.subplots(4, 3, figsize=(15, 12), squeeze=False)
    fig.suptitle("Figure 2: Initial choices across treatment sequences", fontsize=14)
    for row, treatment in enumerate(treatments):
        for col, period in enumerate(periods):
            records = [r for r in table if r["treatment"] == treatment and r["period"] == period]
            n = records[0]["n_choices"] if records else 0
            frame = "P" if tasks_in(treatment)[int(period[0]) - 1] == "P" else "A"
            title = f"{treatment} | rounds {period} | {frame}\n{n} choices"
            draw_panel(axes[row, col], records, title, frame=frame)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(png, dpi=FIGURE_DPI)
    plt.close(fig)
    return files + [png]
