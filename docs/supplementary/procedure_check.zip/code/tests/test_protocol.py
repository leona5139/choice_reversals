"""Offline checks of the revised lottery and information sequence.

These scripted replies test software behavior. They are not model observations.
Run from the repository root with python -m unittest discover -s tests -v.
"""

import json
import re
import unittest
from unittest.mock import patch

from prompt import prompt_b
from simulation.protocol import ProtocolError, run_player


CONDITIONS = {
    "4A_4AR": ["A"] * 4 + ["AR"] * 4,
    "4P_4AR": ["P"] * 4 + ["AR"] * 4,
    "2A2P_4AR": ["A", "A", "P", "P"] + ["AR"] * 4,
    "2P2A_4AR": ["P", "P", "A", "A"] + ["AR"] * 4,
}
COMPUTER_A = [7, 2, 10, 1, 8, 3, 9, 0]


def reply(value, cost=0.01):
    return {"text": json.dumps(value), "cost": cost}


def is_confirmation(messages):
    return '"confirm"' in messages[-1]["content"]


def constant_player(a=5):
    def respond(messages):
        if is_confirmation(messages):
            return reply({"confirm": True})
        return reply({"A": a, "B": 10 - a})
    return respond


def calls(record, round_number, phase):
    return [request for request in record["requests"]
            if request["round"] == round_number and request["phase"] == phase]


class CorrectedProtocolTests(unittest.TestCase):
    def test_four_conditions_fixed_allocations_and_confirmed_outcomes(self):
        for condition, tasks in CONDITIONS.items():
            with self.subTest(condition=condition):
                record = run_player(condition, prompt_b, 1, constant_player())
                self.assertEqual(record["status"], "completed")
                self.assertEqual(record["protocol_version"], "independent_uniform_v2")
                self.assertEqual(len(record["rounds"]), 8)
                self.assertEqual([r["task"] for r in record["rounds"].values()], tasks)
                for number, this_round in record["rounds"].items():
                    self.assertEqual(this_round["computer"],
                                     {"A": COMPUTER_A[number - 1],
                                      "B": 10 - COMPUTER_A[number - 1]})
                    own_win = this_round["draw"]["ticket"] <= 10
                    self.assertEqual(this_round["draw"]["group"],
                                     "participant" if own_win else "computer")
                    expected_initial = None if tasks[number - 1] == "P" and not own_win else {"A": 5, "B": 5}
                    self.assertEqual(this_round["initial"], expected_initial)
                    expected_revision = {"A": 5, "B": 5} if tasks[number - 1] == "AR" and own_win else None
                    self.assertEqual(this_round["revision"], expected_revision)
                    winning_position = this_round["draw"]["ticket"] - (0 if own_win else 10)
                    a_tickets = 5 if own_win else COMPUTER_A[number - 1]
                    self.assertEqual(this_round["winner"],
                                     "A" if winning_position <= a_tickets else "B")
                    if expected_initial is not None:
                        confirmed = calls(record, number, "initial_confirmation")
                        self.assertTrue(confirmed)
                        self.assertEqual(confirmed[-1]["parsed"], {"confirm": True})
                self.assertEqual(record["reversals"], 0)
                payment_round = record["payment"]["round"]
                self.assertIn(payment_round, range(1, 9))
                self.assertEqual(record["payment"]["household"],
                                 record["rounds"][payment_round]["winner"])

    def test_confirmations_display_pre_draw_and_conditional_probabilities(self):
        record = run_player("4P_4AR", prompt_b, 1, constant_player(3))
        # Seed 1 makes the participant group win rounds 1 and 5.
        post = calls(record, 1, "initial_confirmation")[0]["messages"][-1]["content"]
        self.assertIn("3/10", post)
        self.assertIn("7/10", post)
        initial = calls(record, 5, "initial_confirmation")[0]["messages"][-1]["content"]
        self.assertIn("11/20", initial)  # computer 8 plus participant 3
        self.assertIn("9/20", initial)
        revision = calls(record, 5, "revision_confirmation")[0]["messages"][-1]["content"]
        self.assertIn("3/10", revision)
        self.assertIn("7/10", revision)
        post_information = "\n".join(m["content"] for m in calls(record, 1, "initial_allocation")[0]["messages"])
        self.assertIn("1/10", post_information)
        initial_information = "\n".join(m["content"] for m in calls(record, 5, "initial_allocation")[0]["messages"])
        self.assertIn("1/20", initial_information)

    def test_changed_candidate_is_redisplayed_until_explicit_confirmation(self):
        first_confirmation = True

        def respond(messages):
            nonlocal first_confirmation
            if is_confirmation(messages):
                if first_confirmation:
                    first_confirmation = False
                    return reply({"confirm": False, "A": 3, "B": 7})
                return reply({"confirm": True})
            return reply({"A": 5, "B": 5})

        record = run_player("4A_4AR", prompt_b, 1, respond)
        review_calls = calls(record, 1, "initial_confirmation")
        self.assertEqual(len(review_calls), 2)
        self.assertIn("12/20", review_calls[0]["messages"][-1]["content"])
        self.assertIn("10/20", review_calls[1]["messages"][-1]["content"])
        self.assertEqual(record["rounds"][1]["initial"], {"A": 3, "B": 7})
        self.assertEqual(record["reversals"], 0,
                         "An initial confirmation edit is not a later choice reversal.")
        self.assertEqual(review_calls[-1]["parsed"], {"confirm": True})

    def test_surprise_reversal_is_distinct_from_confirmation_edits(self):
        changed_after_reveal = False

        def respond(messages):
            nonlocal changed_after_reveal
            if is_confirmation(messages):
                return reply({"confirm": True})
            question = messages[-1]["content"]
            # A revision allocation has a prior allocation in the same history;
            # the protocol uses a separate prompt after revealing the group.
            if re.search(r"Round\s+5\b", question, re.I) and "earlier confirmed allocation" in question:
                changed_after_reveal = True
                return reply({"A": 5, "B": 5})
            return reply({"A": 2, "B": 8})

        record = run_player("4A_4AR", prompt_b, 1, respond)
        self.assertTrue(changed_after_reveal)
        self.assertEqual(record["rounds"][5]["initial"], {"A": 2, "B": 8})
        self.assertEqual(record["rounds"][5]["revision"], {"A": 5, "B": 5})
        self.assertEqual(record["reversals"], 1)
        self.assertTrue(calls(record, 5, "revision_confirmation"))

    def test_all_four_initial_ar_decisions_precede_any_revision(self):
        record = run_player("4A_4AR", prompt_b, 1, constant_player())
        initial = [r["index"] for r in record["requests"]
                   if r["round"] >= 5 and r["phase"] == "initial_confirmation"]
        revision = [r["index"] for r in record["requests"]
                    if r["phase"].startswith("revision")]
        self.assertEqual(len(initial), 4)
        self.assertTrue(revision)
        self.assertLess(max(initial), min(revision))
        for request in record["requests"]:
            if request["phase"].startswith("initial"):
                text = "\n".join(m["content"] for m in request["messages"])
                mentioned = [int(n) for n in re.findall(r"\bround\s+([1-8])\b", text, re.I)]
                self.assertTrue(all(n <= request["round"] for n in mentioned),
                                "A future round appeared in participant history.")
                self.assertNotIn("surprise", text.lower())

    def test_uniform_draws_have_no_fixed_two_wins_quota(self):
        record = run_player("4A_4AR", prompt_b, 1, constant_player())
        observed = [r["draw"]["ticket"] for r in record["rounds"].values()]
        self.assertEqual(observed, [5, 19, 3, 9, 4, 16, 15, 16])
        self.assertEqual(sum(t <= 10 for t in observed[:4]), 3)
        self.assertEqual(sum(t <= 10 for t in observed[4:]), 1)
        # Confirmation changes must not consume random draws or move outcomes.
        counter = 0

        def change_once(messages):
            nonlocal counter
            if is_confirmation(messages):
                counter += 1
                if counter == 1:
                    return reply({"confirm": False, "A": 4, "B": 6})
                return reply({"confirm": True})
            return reply({"A": 5, "B": 5})

        altered = run_player("4A_4AR", prompt_b, 1, change_once)
        self.assertEqual([r["draw"] for r in record["rounds"].values()],
                         [r["draw"] for r in altered["rounds"].values()])
        self.assertEqual(record["payment"]["round"], altered["payment"]["round"])

    def test_participant_histories_are_separate(self):
        first = run_player("4A_4AR", prompt_b, 1, constant_player(2))
        second = run_player("4A_4AR", prompt_b, 2, constant_player(8))
        opening = second["requests"][0]["messages"]
        self.assertFalse(any(m["role"] == "assistant" for m in opening))
        self.assertNotIn(first["requests"][0]["reply"]["text"],
                         "\n".join(m["content"] for m in opening))
        self.assertEqual(len([m for m in opening if m["role"] == "system"]), 1)

    def test_computer_winning_post_round_shows_allocation_and_interpretable_outcome(self):
        record = run_player("4P_4AR", prompt_b, 1, constant_player())
        self.assertEqual(record["rounds"][2]["draw"], {"group": "computer", "ticket": 19})
        self.assertFalse([r for r in record["requests"] if r["round"] == 2])
        information = [record["messages"][event["message_index"]]["content"]
                       for event in record["events"]
                       if event["kind"] == "message" and event.get("round") == 2
                       and event.get("phase") == "information"]
        self.assertEqual(len(information), 3)
        self.assertIn("2 of its ten tickets to Household A and 8 to Household B", information[0])
        self.assertIn("1/10", information[1])
        self.assertIn("ticket 19", information[2])
        self.assertIn("Household B", information[2])
        next_model_input = calls(record, 3, "initial_allocation")[0]["messages"]
        for text in information:
            self.assertIn({"role": "user", "content": text}, next_model_input)

    def test_ante_outcomes_reveal_group_without_ticket_or_household(self):
        record = run_player("4A_4AR", prompt_b, 1, constant_player())
        for number in (1, 5):
            info = [record["messages"][event["message_index"]]["content"]
                    for event in record["events"]
                    if event["kind"] == "message" and event.get("round") == number
                    and event.get("phase") == "information"]
            outcome = info[-1]
            self.assertIn("participant group", outcome)
            self.assertIn("ticket number is not revealed", outcome.lower())
            self.assertNotIn("Household", outcome)
            actual_ticket = record["rounds"][number]["draw"]["ticket"]
            self.assertNotRegex(outcome, rf"ticket(?: number)?(?: is)?\s+{actual_ticket}\b")
        # Round 1 group feedback is part of the input to the next decision.
        history = calls(record, 2, "initial_allocation")[0]["messages"]
        self.assertTrue(any("Round 1 is complete" in m["content"] and
                            "participant group" in m["content"] for m in history))

    def test_exact_ticket_remains_hidden_until_post_choice_is_confirmed(self):
        record = run_player("4P_4AR", prompt_b, 1, constant_player())
        for request in record["requests"]:
            if request["round"] == 1:
                history = "\n".join(m["content"] for m in request["messages"])
                self.assertNotRegex(history, r"winning ticket is ticket 5\b")
                self.assertNotRegex(history, r"ticket number (?:is )?5\b")
        last_confirmation = calls(record, 1, "initial_confirmation")[-1]
        first_confirmed_event = next(e for e in record["events"]
                                     if e["kind"] == "choice_confirmed" and e["round"] == 1)
        outcome_event = next(e for e in record["events"]
                             if e["kind"] == "message" and e.get("round") == 1
                             and "winning ticket is ticket 5" in record["messages"][e["message_index"]]["content"])
        self.assertEqual(first_confirmed_event["request_index"], last_confirmation["index"])
        self.assertLess(first_confirmed_event["index"], outcome_event["index"])

    def test_every_possible_ticket_has_the_announced_allocation_payoff(self):
        # Enumerating the 20 equally likely tickets establishes each household's
        # exact winning count, including boundary allocations of zero and ten.
        class FixedTicketDraw:
            def __init__(self, ticket):
                self.ticket = ticket

            def randint(self, low, high):
                if (low, high) != (1, 20):
                    raise AssertionError("The draw must use all twenty tickets.")
                return self.ticket

            def choice(self, values):
                return list(values)[0]

        for a in range(11):
            wins = [0] * 8
            own_wins = [0] * 8
            for ticket in range(1, 21):
                with patch("simulation.protocol.random.Random", return_value=FixedTicketDraw(ticket)):
                    record = run_player("4A_4AR", prompt_b, 1, constant_player(a))
                for number, this_round in record["rounds"].items():
                    if this_round["winner"] == "A":
                        wins[number - 1] += 1
                        if ticket <= 10:
                            own_wins[number - 1] += 1
            self.assertEqual(wins, [a + computer for computer in COMPUTER_A])
            self.assertEqual(own_wins, [a] * 8)

    def test_invalid_responses_fail_with_logs_and_without_final_choices(self):
        with self.assertRaises(ProtocolError) as raised:
            run_player("4A_4AR", prompt_b, 1,
                       lambda messages: reply({"A": 5, "B": 4}), max_attempts=3)
        record = raised.exception.record
        self.assertEqual(record["status"], "failed")
        self.assertEqual(len(record["requests"]), 3)
        self.assertTrue(all(r["error"] for r in record["requests"]))
        self.assertIsNone(record["rounds"][1]["initial"])
        self.assertAlmostEqual(record["cost"], 0.03)

    def test_confirmation_limit_never_accepts_an_unconfirmed_choice(self):
        def never_confirm(messages):
            if is_confirmation(messages):
                return reply({"confirm": False, "A": 3, "B": 7})
            return reply({"A": 5, "B": 5})

        with self.assertRaises(ProtocolError) as raised:
            run_player("4A_4AR", prompt_b, 1, never_confirm,
                       max_confirmations=2)
        record = raised.exception.record
        self.assertEqual(record["status"], "failed")
        self.assertEqual(len(calls(record, 1, "initial_confirmation")), 2)
        self.assertIsNone(record["rounds"][1]["initial"])

    def test_format_retry_is_visible_and_requires_plain_json(self):
        number = 0

        def respond(messages):
            nonlocal number
            number += 1
            if number == 1:
                return {"text": '```json\n{"A": 5, "B": 5}\n```', "cost": 0.02}
            return constant_player()(messages)

        record = run_player("4A_4AR", prompt_b, 1, respond)
        attempts = calls(record, 1, "initial_allocation")
        self.assertEqual(len(attempts), 2)
        self.assertTrue(attempts[0]["error"])
        self.assertIsNone(attempts[1]["error"])
        retry_history = attempts[1]["messages"]
        self.assertTrue(any(m["role"] == "assistant" and "```json" in m["content"]
                            for m in retry_history))

    def test_provider_failure_preserves_incomplete_status_without_account_details(self):
        def fail(messages):
            raise RuntimeError("private-account-detail")

        with self.assertRaises(ProtocolError) as raised:
            run_player("4A_4AR", prompt_b, 1, fail, max_attempts=2)
        record = raised.exception.record
        self.assertEqual(record["status"], "failed")
        self.assertEqual(len(record["requests"]), 2)
        self.assertEqual(record["cost_unknown_requests"], 2)
        self.assertIsNone(record["rounds"][1]["initial"])
        self.assertTrue(all(r["error"] == "provider error: RuntimeError"
                            for r in record["requests"]))
        self.assertNotIn("private-account-detail", json.dumps(record))

    def test_unknown_provider_cost_is_not_reported_as_a_known_zero_cost(self):
        def respond(messages):
            value = {"confirm": True} if is_confirmation(messages) else {"A": 5, "B": 5}
            return reply(value, cost=None)

        record = run_player("4A_4AR", prompt_b, 1, respond)
        self.assertEqual(record["cost_unknown_requests"], len(record["requests"]))
        self.assertEqual(record["cost"], 0.0)  # Only the sum of known reported costs.


if __name__ == "__main__":
    unittest.main()
