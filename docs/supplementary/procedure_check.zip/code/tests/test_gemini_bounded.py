"""Offline checks. Fake transports never make network requests."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError

from simulation.gemini_bounded import BudgetExceeded, GeminiBounded, GeminiRequestError, SharedBudget, build_payload


class GeminiBoundedTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "budget.json"
        self.key = patch.dict(os.environ, {"GEMINI_API_KEY": "offline-test-secret"})
        self.key.start()
        self.addCleanup(self.key.stop)
        self.messages = [{"role": "system", "content": "system"},
                         {"role": "user", "content": "first"},
                         {"role": "user", "content": "second"},
                         {"role": "assistant", "content": "prior"},
                         {"role": "user", "content": "next"}]

    def client(self, transport, budget=None):
        return GeminiBounded("gemini-3.5-flash-lite", budget or SharedBudget(self.path),
                             0.30, 2.50, transport=transport, requests_per_minute=1000000)

    def response(self, finish="STOP"):
        return {"modelVersion": "gemini-3.5-flash-lite", "candidates": [
            {"finishReason": finish, "content": {"parts": [
                {"text": "private thinking", "thought": True},
                {"text": '{"A":5,'}, {"text": '"B":5}'}]}}],
            "usageMetadata": {"promptTokenCount": 100, "candidatesTokenCount": 12,
                              "thoughtsTokenCount": 20, "totalTokenCount": 132}}

    def test_payload_and_secret_header_and_pre_call_reservation(self):
        def transport(url, headers, body, timeout):
            state = json.loads(self.path.read_text())
            self.assertEqual(len(state["reservations"]), 1)
            self.assertNotIn("offline-test-secret", self.path.read_text())
            self.assertNotIn("offline-test-secret", url)
            self.assertNotIn("offline-test-secret", body.decode())
            self.assertEqual(headers["X-goog-api-key"], "offline-test-secret")
            self.assertEqual(timeout, 60)
            payload = json.loads(body)
            self.assertEqual(payload["contents"][0]["parts"][0]["text"], "first\n\nsecond")
            self.assertEqual(payload["contents"][1]["role"], "model")
            self.assertEqual(payload["generationConfig"]["thinkingConfig"], {"thinkingLevel": "MINIMAL"})
            return self.response()
        reply = self.client(transport).chat(self.messages)
        self.assertEqual(reply["text"], '{"A":5,"B":5}')
        self.assertIsNone(reply["cost"])
        self.assertAlmostEqual(reply["estimated_cost_usd"], (100 * .30 + 32 * 2.50) / 1000000)
        self.assertEqual(reply["request_payload"], build_payload(self.messages,
                         {"temperature": 1, "max_output_tokens": 1024, "thinking_level": "MINIMAL"}))

    def test_failed_call_retains_reservation_and_resume_limit(self):
        def failure(*args):
            raise HTTPError("url", 429, "offline-test-secret", {}, None)
        client = self.client(failure, SharedBudget(self.path, max_calls=1))
        with self.assertRaisesRegex(GeminiRequestError, "^HTTP 429$"):
            client.chat(self.messages)
        calls = []
        resumed = self.client(lambda *args: calls.append(args), SharedBudget(self.path, max_calls=1))
        with self.assertRaises(BudgetExceeded):
            resumed.chat(self.messages)
        self.assertEqual(calls, [])
        self.assertEqual(len(json.loads(self.path.read_text())["reservations"]), 1)

    def test_budget_stops_before_transport(self):
        calls = []
        client = self.client(lambda *args: calls.append(args), SharedBudget(self.path, max_reserved_usd=.000001))
        with self.assertRaises(BudgetExceeded):
            client.chat(self.messages)
        self.assertEqual(calls, [])
        self.assertFalse(self.path.exists())

    def test_transport_error_is_sanitized_and_not_retried(self):
        calls = []
        def failure(*args):
            calls.append(1)
            raise RuntimeError("offline-test-secret with provider details")
        with self.assertRaisesRegex(GeminiRequestError, "^RuntimeError$"):
            self.client(failure).chat(self.messages)
        self.assertEqual(calls, [1])

    def test_non_stop_raw_response_preserved_but_not_accepted(self):
        raw = self.response("MAX_TOKENS")
        reply = self.client(lambda *args: raw).chat(self.messages)
        self.assertEqual(reply["text"], "")
        self.assertEqual(reply["candidate_text"], '{"A":5,"B":5}')
        self.assertEqual(reply["raw"], raw)
        self.assertIsNotNone(reply["estimated_cost_usd"])

    def test_successive_clients_share_cumulative_reservations(self):
        first = self.client(lambda *args: self.response()).chat(self.messages)
        second = self.client(lambda *args: self.response(), SharedBudget(self.path)).chat(self.messages)
        self.assertEqual(first["budget_reservation"]["sequence"], 1)
        self.assertEqual(second["budget_reservation"]["sequence"], 2)
        state = json.loads(self.path.read_text())
        self.assertAlmostEqual(float(state["reserved_usd"]),
                               2 * float(first["budget_reservation"]["reserved_usd"]))

    def test_budget_configuration_cannot_change_on_resume(self):
        self.client(lambda *args: self.response()).chat(self.messages)
        calls = []
        changed = self.client(lambda *args: calls.append(args), SharedBudget(self.path, max_reserved_usd=3))
        with self.assertRaises(BudgetExceeded):
            changed.chat(self.messages)
        self.assertEqual(calls, [])

    def test_nonfinite_or_zero_prices_and_rate_are_rejected(self):
        for rate in (0, -1, float("nan"), float("inf")):
            with self.subTest(rate=rate), self.assertRaises(ValueError):
                GeminiBounded("gemini-3.5-flash-lite", SharedBudget(self.path), rate, 2.5,
                               transport=lambda *args: self.response())
        for rate in (0, float("nan"), float("inf")):
            with self.subTest(requests_per_minute=rate), self.assertRaises(ValueError):
                GeminiBounded("gemini-3.5-flash-lite", SharedBudget(self.path), .3, 2.5,
                               transport=lambda *args: self.response(), requests_per_minute=rate)


if __name__ == "__main__":
    unittest.main()
