"""Run the revised pilot separately from the original saved experiment.

Offline control check (no credentials or model calls):
    python -m simulation.run_corrected --dry-run
Real fixed-plan pilot, using keys in .env:
    uv run python -m simulation.run_corrected
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import uuid
import zlib

from prompt import prompt_b
from simulation.protocol import ProtocolError, run_player
from simulation.treatments import TREATMENTS

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODELS = ("gemini:gemini-3.1-flash-lite", "gemini:gemini-3.5-flash-lite")
PROTOCOL = "independent_uniform_v2"
GEMINI_RATES = {
    "gemini-3.1-flash-lite": {"input_per_million_usd": 0.25, "output_per_million_usd": 1.50},
    "gemini-3.5-flash-lite": {"input_per_million_usd": 0.30, "output_per_million_usd": 2.50},
}
APPEND_LOCK = threading.Lock()


def write_json(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def append_jsonl(path, value):
    with APPEND_LOCK:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(value, ensure_ascii=False) + "\n")
            f.flush()


def read_jsonl(path):
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def file_digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def seed_for(run_name, treatment, number):
    return zlib.crc32(f"{run_name}|{treatment}|{number}".encode())


def planned_players(run_name, models, number):
    rows = []
    for provider, model in models:
        for treatment in TREATMENTS:
            for n in range(number):
                rows.append({
                    "player_id": f"{treatment}|{provider}|{model}|t=1.0|{prompt_b.PROMPT_VERSION}|{n}",
                    "run_name": run_name, "treatment": treatment,
                    "provider": provider, "model": model, "temperature": 1.0,
                    "prompt_version": prompt_b.PROMPT_VERSION, "player_number": n,
                    "seed": seed_for(run_name, treatment, n),
                })
    return rows


def scrub_error(value):
    text = str(value)
    for name in ("GEMINI_API_KEY", "OPENROUTER_API_KEY"):
        key = os.environ.get(name)
        if key:
            text = text.replace(key, "[credential removed]")
    return text


def offline_reply(messages):
    """A scripted controller, never evidence of model behavior."""
    question = messages[-1]["content"]
    # The protocol names this explicit confirmation action in its review question.
    if '"confirm"' in question:
        value = {"confirm": True}
    else:
        value = {"A": 5, "B": 5}
    return {"text": json.dumps(value), "cost": 0.0, "source": "scripted_control"}


def journaled_reply(callback, folder, setup, evidence_kind):
    """Keep each callback input and result on disk, including interrupted runs.

    These are application callbacks. Provider SDK retries are not separately
    observable here. Unfinished callbacks have unknown outcomes and costs.
    """
    attempt_id = uuid.uuid4().hex
    counter = 0

    def reply(messages):
        nonlocal counter
        counter += 1
        identity = {"attempt_id": attempt_id, "callback": counter,
                    "player_id": setup["player_id"], "evidence_kind": evidence_kind}
        append_jsonl(folder / "callback_journal.jsonl",
                     {**identity, "event": "started", "messages": messages})
        try:
            result = callback(messages)
        except BaseException as error:
            append_jsonl(folder / "callback_journal.jsonl",
                         {**identity, "event": "failed", "error_class": type(error).__name__})
            raise
        append_jsonl(folder / "callback_journal.jsonl",
                     {**identity, "event": "returned", "reply": result})
        return result

    return reply


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="scripted control only; no model calls")
    parser.add_argument("--model", action="append", help="provider:model; repeat for at least two models")
    parser.add_argument("--players", type=int, default=2, help="fixed participants per model and condition (default 2)")
    parser.add_argument("--run-name", default="pilot_3")
    parser.add_argument("--requests-per-minute", type=float, default=10)
    parser.add_argument("--retry-failed", action="store_true", help="retry recorded failures; retains every earlier attempt")
    parser.add_argument("--max-confirmations", type=int, default=12)
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--workers", type=int, default=1,
                        help="parallel participants, 1-4; use 1 with run_checkpointed")
    args = parser.parse_args(argv)
    if args.players < 1 or args.max_confirmations < 1 or args.max_attempts < 1:
        parser.error("players and both limits must be positive")
    if args.requests_per_minute <= 0:
        parser.error("requests-per-minute must be positive")
    if not 1 <= args.workers <= 4:
        parser.error("workers must be between 1 and 4")
    if args.run_name == "pilot_1" or not args.run_name.replace("_", "").replace("-", "").isalnum():
        parser.error("use a new simple run name; pilot_1 is reserved for the original data")
    try:
        models = [tuple(spec.split(":", 1)) for spec in (args.model or DEFAULT_MODELS)]
        if any(len(s) != 2 or s[0] not in {"gemini", "openrouter"} or not s[1] for s in models):
            raise ValueError
    except ValueError:
        parser.error("models must use gemini:model or openrouter:model")
    if len(set(models)) < 2 or len(models) != len(set(models)):
        parser.error("use at least two distinct models, without duplicate entries")

    evidence_kind = "synthetic_control_test" if args.dry_run else "model_pilot"
    bounded_gemini = not args.dry_run and all(provider == "gemini" for provider, _ in models)
    if args.workers > 1 and not (args.dry_run or bounded_gemini):
        parser.error("parallel participants require bounded Gemini clients or --dry-run")
    if bounded_gemini and any(model not in GEMINI_RATES for _, model in models):
        parser.error("bounded Gemini runs require the two models with verified published prices in GEMINI_RATES")
    if args.dry_run:
        models = [("scripted", "control_one"), ("scripted", "control_two")]
        folder = ROOT / "output" / "validation" / PROTOCOL / args.run_name
    else:
        # Import only for real runs. Offline checks need the standard library alone.
        try:
            from dotenv import load_dotenv
        except ImportError:
            pass  # Environment-only authentication needs no extra package.
        else:
            load_dotenv(ROOT / ".env", override=False)
        keys = {"gemini": "GEMINI_API_KEY", "openrouter": "OPENROUTER_API_KEY"}
        missing = sorted({keys[provider] for provider, _ in models if not os.environ.get(keys[provider])})
        if missing:
            print("Real pilot not started. Configure " + ", ".join(missing) + " in the local .env file. Do not commit that file.", file=sys.stderr)
            return 2
        folder = ROOT / "output" / "results" / args.run_name

    folder.mkdir(parents=True, exist_ok=True)
    roster = planned_players(args.run_name, models, args.players)
    manifest = {
        "schema_version": 1, "evidence_kind": evidence_kind, "protocol_version": PROTOCOL,
        "run_name": args.run_name, "temperature": 1.0,
        "players_per_model_condition": args.players, "planned_participants": len(roster),
        "models": [{"provider": p, "model": m} for p, m in models],
        "conditions": TREATMENTS, "max_confirmations": args.max_confirmations,
        "max_attempts": args.max_attempts, "requests_per_minute": args.requests_per_minute,
        "workers": args.workers,
        "draw_policy": "independent uniform ticket from 1 to 20 in each round; one uniform payment round",
        "draw_policy_source": "Per-round lottery reconstruction; the original study's cross-round randomization code was unavailable.",
        "sampling": "Fixed roster before calls; do not add or remove participants based on their allocations.",
        "protocol_sha256": file_digest(ROOT / "simulation" / "protocol.py"),
        "prompt_sha256": file_digest(ROOT / "prompt" / "prompt_b.py"),
        "runner_sha256": file_digest(Path(__file__)), "roster": roster,
    }
    if bounded_gemini:
        manifest["api_settings"] = {
            "bounded_rest": True, "thinking_level": "MINIMAL", "response_mime_type": "application/json",
            "max_output_tokens": 1024, "timeout_seconds": 60,
            "max_calls": 500, "max_reserved_usd": 2.0,
            "rates": {model: GEMINI_RATES[model] for _, model in models},
        }
        manifest["client_sha256"] = file_digest(ROOT / "simulation" / "gemini_bounded.py")
    manifest_path = folder / "manifest.json"
    if manifest_path.exists():
        if json.loads(manifest_path.read_text()) != manifest:
            print("Existing run has a different plan or source version. Use a new run name; no results were changed.", file=sys.stderr)
            return 2
    else:
        if any(folder.iterdir()):
            print("Refusing to mix a new plan with pre-existing files. Use a new run name.", file=sys.stderr)
            return 2
        write_json(manifest_path, manifest)

    from analysis.check_corrected_pilot import validate_run
    try:
        validate_run(folder, allow_synthetic=args.dry_run,
                     require_complete=False, write_outputs=False)
    except (ValueError, OSError) as error:
        print(f"Existing run failed validation before any new calls: {error}", file=sys.stderr)
        return 2

    records = read_jsonl(folder / "players.jsonl")
    already = {r["player_id"] for r in records}
    if len(already) != len(records):
        print("Duplicate participant IDs in existing results; stopping.", file=sys.stderr)
        return 2
    if not already.issubset({r["player_id"] for r in roster}):
        print("Existing records are outside this fixed plan; stopping.", file=sys.stderr)
        return 2
    earlier_failures = read_jsonl(folder / "failures.jsonl")
    failed_before = {r["player_id"] for r in earlier_failures}
    clients = {}
    budget = None
    if bounded_gemini:
        from simulation.gemini_bounded import GeminiBounded, SharedBudget
        budget = SharedBudget(folder / "budget_ledger.json", max_reserved_usd=2.0, max_calls=500)
    initialization_errors = {}
    if not args.dry_run:
        # One shared client per model preserves its rate limiter across workers.
        # Initialize every selected model before starting any participant.
        for provider, model in models:
            try:
                if bounded_gemini:
                    clients[provider, model] = GeminiBounded(
                        model, budget, **GEMINI_RATES[model],
                        max_output_tokens=1024, timeout_seconds=60,
                        thinking_level="MINIMAL", requests_per_minute=args.requests_per_minute,
                    )
                else:
                    from llm import LLM
                    clients[provider, model] = LLM(provider, model, temperature=1.0,
                                                   requests_per_minute=args.requests_per_minute)
            except Exception as error:
                initialization_errors[provider, model] = scrub_error(error)
    invocation_failures = 0
    pending = []
    for setup in roster:
        ident = setup["player_id"]
        if ident in already:
            continue
        if ident in failed_before and not args.retry_failed:
            invocation_failures += 1
            print(f"Not retrying failed participant {ident}; use --retry-failed to retain and retry failures.")
            continue
        key = (setup["provider"], setup["model"])
        if key in initialization_errors:
            failed = {**setup, "status": "failed", "failure_stage": "provider_initialization", "evidence_kind": evidence_kind,
                      "protocol_version": PROTOCOL, "error": initialization_errors[key], "cost": 0.0,
                      "cost_unknown_requests": 0, "requests": []}
            append_jsonl(folder / "failures.jsonl", failed)
            invocation_failures += 1
            continue
        pending.append(setup)
    if initialization_errors:
        print("A selected model client could not initialize. No participant calls were started.", file=sys.stderr)
        return 1

    stop = threading.Event()

    def execute(setup):
        if stop.is_set():
            return None
        callback = offline_reply if args.dry_run else clients[setup["provider"], setup["model"]].chat

        def guarded_reply(messages):
            if stop.is_set() and bounded_gemini:
                from simulation.gemini_bounded import BudgetExceeded
                raise BudgetExceeded("run stopped at its budget limit; no call made")
            return callback(messages)

        try:
            reply = journaled_reply(guarded_reply, folder, setup, evidence_kind)
            result = run_player(setup["treatment"], prompt_b, setup["seed"], reply,
                                max_confirmations=args.max_confirmations, max_attempts=args.max_attempts)
        except ProtocolError as error:
            failed = {**error.record, **setup, "evidence_kind": evidence_kind, "error": scrub_error(error)}
            if any(q.get("error") == "provider error: BudgetExceeded" for q in failed.get("requests", [])):
                stop.set()
            return failed
        return {**result, **setup, "evidence_kind": evidence_kind}

    def save_result(record):
        nonlocal invocation_failures
        if record is None:
            return
        ident = record["player_id"]
        if record["status"] == "failed":
            failed = record
            append_jsonl(folder / "failures.jsonl", failed)
            invocation_failures += 1
            print(f"Incomplete participant {ident}: {failed['error']}", file=sys.stderr)
            return
        append_jsonl(folder / "players.jsonl", record)
        already.add(ident)
        print(f"Completed {len(already)}/{len(roster)}: {ident}")

    if args.workers == 1:
        # Keep record-by-record execution compatible with the checkpoint wrapper.
        for setup in pending:
            save_result(execute(setup))
            if stop.is_set():
                break
    else:
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(execute, setup) for setup in pending]
            for future in as_completed(futures):
                if not future.cancelled():
                    save_result(future.result())
                if stop.is_set():
                    for waiting in futures:
                        waiting.cancel()
    if stop.is_set():
        print("The run reached its spending reservation or call limit. Pending participants were cancelled.", file=sys.stderr)

    try:
        summary = validate_run(folder, allow_synthetic=args.dry_run)
    except (ValueError, OSError) as error:
        print(f"Run incomplete or invalid: {error}", file=sys.stderr)
        return 1
    print(f"Verified {summary['completed_participants']} completed participants; {summary['eligible_revisions']} eligible post-reveal choices.")
    print(f"Saved {folder.relative_to(ROOT)}. Evidence kind: {evidence_kind}.")
    return 1 if invocation_failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
