"""Gemini REST calls with persisted, conservative request-budget reservations.

The input reservation uses UTF-8 bytes plus fixed framing allowances. This is a
conservative estimate, not a guarantee about Google's tokenizer or final bill.
Every generation attempt retains its full reservation, including failed calls.
No credentials, request headers, or provider error bodies enter the ledger.
"""

from contextlib import contextmanager
from decimal import Decimal, InvalidOperation
import json
import math
import os
from pathlib import Path
import re
import threading
import time
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, Request, build_opener


class BudgetExceeded(RuntimeError):
    pass


class GeminiRequestError(RuntimeError):
    pass


def build_payload(messages, settings):
    """Match the existing Gemini adapter's system and consecutive-role handling."""
    contents = []
    system = None
    for message in messages:
        role, text = message["role"], message["content"]
        if not isinstance(text, str) or role not in {"system", "user", "assistant"}:
            raise ValueError("invalid message role or content")
        if role == "system":
            system = text
            continue
        role = "model" if role == "assistant" else "user"
        if contents and contents[-1]["role"] == role:
            contents[-1]["parts"][0]["text"] += "\n\n" + text
        else:
            contents.append({"role": role, "parts": [{"text": text}]})
    payload = {"contents": contents, "generationConfig": {
        "temperature": settings.get("temperature", 1.0),
        "maxOutputTokens": settings["max_output_tokens"],
        "candidateCount": 1,
        "responseMimeType": "application/json",
        "thinkingConfig": {"thinkingLevel": settings["thinking_level"]},
    }}
    if system is not None:
        payload["systemInstruction"] = {"parts": [{"text": system}]}
    return payload


def _decimal(value):
    try:
        result = Decimal(str(value))
    except InvalidOperation as error:
        raise ValueError("invalid budget or price") from error
    if not result.is_finite() or result < 0:
        raise ValueError("invalid budget or price")
    return result


class SharedBudget:
    """A cumulative ledger shared by models and reused on resumed invocations."""

    def __init__(self, path, max_reserved_usd=2.0, max_calls=500):
        self.path = Path(path)
        self.max_reserved_usd = _decimal(max_reserved_usd)
        if self.max_reserved_usd <= 0 or type(max_calls) is not int or max_calls < 1:
            raise ValueError("positive budget and call limit required")
        self.max_calls = max_calls
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._thread_lock = threading.Lock()

    @contextmanager
    def _locked(self):
        lock = self.path.with_name(self.path.name + ".lock")
        with self._thread_lock:
            deadline = time.monotonic() + 5
            while True:
                try:
                    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                    break
                except FileExistsError:
                    if time.monotonic() >= deadline:
                        raise BudgetExceeded("budget ledger locked; no call made") from None
                    time.sleep(0.05)
            try:
                os.close(descriptor)
                yield
            finally:
                lock.unlink()

    def _load(self):
        if not self.path.exists():
            return {"schema_version": 1, "max_reserved_usd": str(self.max_reserved_usd),
                    "max_calls": self.max_calls, "reserved_usd": "0", "reservations": []}
        state = json.loads(self.path.read_text(encoding="utf-8"))
        if (state.get("schema_version") != 1 or state.get("max_calls") != self.max_calls
                or _decimal(state.get("max_reserved_usd")) != self.max_reserved_usd):
            raise BudgetExceeded("existing budget configuration differs; no call made")
        reservations = state["reservations"]
        if (len(reservations) > self.max_calls
                or [r["sequence"] for r in reservations] != list(range(1, len(reservations) + 1))
                or sum((_decimal(r["reserved_usd"]) for r in reservations), Decimal(0))
                != _decimal(state["reserved_usd"])
                or _decimal(state["reserved_usd"]) > self.max_reserved_usd):
            raise BudgetExceeded("invalid cumulative budget ledger; no call made")
        return state

    def reserve(self, model, payload, input_per_million_usd, output_per_million_usd):
        input_rate, output_rate = _decimal(input_per_million_usd), _decimal(output_per_million_usd)
        if input_rate <= 0 or output_rate <= 0:
            raise ValueError("positive input and output prices required")
        parts = [part for turn in payload["contents"] for part in turn["parts"]]
        parts += payload.get("systemInstruction", {}).get("parts", [])
        input_bytes = sum(len(part["text"].encode("utf-8")) for part in parts)
        if input_bytes > 131072:
            raise BudgetExceeded("input byte safety limit exceeded; no call made")
        input_estimate = input_bytes + 64 * len(parts) + 2048
        output_limit = payload["generationConfig"]["maxOutputTokens"]
        amount = (input_estimate * input_rate + output_limit * output_rate) / Decimal(1000000)
        with self._locked():
            state = self._load()
            cumulative = _decimal(state["reserved_usd"]) + amount
            if len(state["reservations"]) >= self.max_calls or cumulative > self.max_reserved_usd:
                raise BudgetExceeded("generation-call or reserved-cost limit reached; no call made")
            reservation = {
                "sequence": len(state["reservations"]) + 1, "model": model,
                "input_utf8_bytes": input_bytes, "part_count": len(parts),
                "input_token_estimate": input_estimate, "output_token_limit": output_limit,
                "input_per_million_usd": str(input_rate), "output_per_million_usd": str(output_rate),
                "reserved_usd": str(amount), "cumulative_reserved_usd": str(cumulative),
                "input_basis": "UTF-8 bytes + 64 per text part + 2048 framing allowance; conservative estimate",
            }
            state["reservations"].append(reservation)
            state["reserved_usd"] = str(cumulative)
            temporary = self.path.with_name(self.path.name + ".tmp")
            with temporary.open("w", encoding="utf-8") as handle:
                json.dump(state, handle, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            temporary.replace(self.path)
        return dict(reservation)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        raise GeminiRequestError(f"HTTP {int(code)}")


def _transport(url, headers, body, timeout):
    request = Request(url, data=body, headers=headers, method="POST")
    # Do not forward the credential header through an HTTP redirect.
    with build_opener(_NoRedirect).open(request, timeout=timeout) as response:
        data = response.read(4 * 1024 * 1024 + 1)
        if len(data) > 4 * 1024 * 1024:
            raise GeminiRequestError("response size limit")
        return json.loads(data.decode("utf-8"))


def _usage_estimate(usage, input_rate, output_rate):
    prompt = usage.get("promptTokenCount")
    candidates = usage.get("candidatesTokenCount")
    thoughts = usage.get("thoughtsTokenCount", 0)
    total = usage.get("totalTokenCount")
    if any(type(value) is not int or value < 0 for value in (prompt, candidates, thoughts)):
        return None
    output = candidates + thoughts
    if type(total) is int and total >= prompt:
        output = max(output, total - prompt)
    return float((prompt * input_rate + output * output_rate) / Decimal(1000000))


class GeminiBounded:
    def __init__(self, model, budget, input_per_million_usd, output_per_million_usd,
                 max_output_tokens=1024, timeout_seconds=60, thinking_level="MINIMAL",
                 transport=None, requests_per_minute=60):
        if not re.fullmatch(r"gemini-[A-Za-z0-9_.-]+", model):
            raise ValueError("invalid Gemini model name")
        if type(max_output_tokens) is not int or not 1 <= max_output_tokens <= 1024:
            raise ValueError("max_output_tokens must be between 1 and 1024")
        if (type(timeout_seconds) not in (int, float) or not math.isfinite(timeout_seconds)
                or not 0 < timeout_seconds <= 60
                or type(requests_per_minute) not in (int, float) or not math.isfinite(requests_per_minute)
                or requests_per_minute <= 0 or thinking_level != "MINIMAL"):
            raise ValueError("invalid timeout, rate or thinking setting")
        key = os.environ.get("GEMINI_API_KEY", "").strip()
        if not key:
            raise ValueError("GEMINI_API_KEY is not configured")
        self._key = key
        self.model, self.budget = model, budget
        self.input_rate, self.output_rate = _decimal(input_per_million_usd), _decimal(output_per_million_usd)
        if self.input_rate <= 0 or self.output_rate <= 0:
            raise ValueError("positive input and output prices required")
        self.timeout = timeout_seconds
        self.settings = {"temperature": 1.0, "max_output_tokens": max_output_tokens,
                         "thinking_level": thinking_level}
        self.transport = transport or _transport
        self.interval = 60.0 / requests_per_minute
        self._next_call = 0.0
        self._lock = threading.Lock()

    def chat(self, messages):
        payload = build_payload(messages, self.settings)
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        start = time.monotonic()
        with self._lock:
            delay = max(0.0, self._next_call - time.monotonic())
            if delay:
                time.sleep(delay)
            reservation = self.budget.reserve(self.model, payload, self.input_rate, self.output_rate)
            self._next_call = time.monotonic() + self.interval
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        headers = {"Content-Type": "application/json", "X-goog-api-key": self._key}
        try:
            raw = self.transport(url, headers, body, self.timeout)
        except HTTPError as error:
            raise GeminiRequestError(f"HTTP {int(error.code)}") from None
        except Exception as error:
            raise GeminiRequestError(type(error).__name__) from None
        if not isinstance(raw, dict):
            raise GeminiRequestError("InvalidResponseType")
        if "error" in raw:
            code = raw["error"].get("code") if isinstance(raw["error"], dict) else None
            raise GeminiRequestError(f"HTTP {code}" if type(code) is int else "ProviderError")
        candidates = raw.get("candidates", [])
        if not isinstance(candidates, list):
            raise GeminiRequestError("InvalidCandidatesType")
        candidate = candidates[0] if len(candidates) == 1 and isinstance(candidates[0], dict) else {}
        finish = candidate.get("finishReason")
        candidate_text = "".join(part["text"] for part in candidate.get("content", {}).get("parts", [])
                                 if isinstance(part, dict) and isinstance(part.get("text"), str)
                                 and not part.get("thought", False))
        # A truncated, blocked or absent candidate cannot become an accepted choice.
        text = candidate_text if finish == "STOP" else ""
        usage = raw.get("usageMetadata", {})
        if not isinstance(usage, dict):
            raise GeminiRequestError("InvalidUsageType")
        return {"text": text, "candidate_text": candidate_text, "cost": None,
                "estimated_cost_usd": _usage_estimate(usage, self.input_rate, self.output_rate),
                "cost_estimate_basis": "uncached input rate; output includes thought tokens; not a billed charge",
                "seconds": round(time.monotonic() - start, 3),
                "request_payload": payload, "requested_model": self.model, "status_code": 200,
                "raw": raw, "usage": usage, "model_version": raw.get("modelVersion"),
                "finish_reason": finish, "budget_reservation": reservation}
