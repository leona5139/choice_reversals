"""Run the fixed pilot in short sessions, stopping after one saved participant.

This wrapper changes only when the process exits. It uses the frozen corrected
runner, manifest, prompts and API client. A participant interrupted before a
complete record is saved restarts from the same planned ID and seed. The earlier
callback journal and budget reservations are retained for the final audit.

Repeat until all planned participants are complete:
    python -m simulation.run_checkpointed --requests-per-minute 60
"""
import argparse
import sys

from analysis.check_corrected_pilot import validate_run
from simulation import run_corrected


class ParticipantSaved(BaseException):
    def __init__(self, folder):
        self.folder = folder


def main(argv=None):
    arguments = list(sys.argv[1:] if argv is None else argv)
    check = argparse.ArgumentParser(add_help=False)
    check.add_argument("--workers", type=int, default=1)
    options, _ = check.parse_known_args(arguments)
    if options.workers != 1:
        raise SystemExit("The checkpoint wrapper requires --workers 1. Use run_corrected directly for parallel work.")
    original_append = run_corrected.append_jsonl

    def append_and_checkpoint(path, value):
        original_append(path, value)
        if path.name == "players.jsonl" and value.get("status") == "completed":
            raise ParticipantSaved(path.parent)

    run_corrected.append_jsonl = append_and_checkpoint
    try:
        return run_corrected.main(arguments)
    except ParticipantSaved as saved:
        summary = validate_run(saved.folder, allow_synthetic="--dry-run" in arguments,
                               require_complete=False)
        print(f"Saved and checked {summary['completed_participants']}/{summary['planned_participants']} participants.")
        print("The next invocation continues with the next unfinished participant.")
        return 0
    finally:
        run_corrected.append_jsonl = original_append


if __name__ == "__main__":
    raise SystemExit(main())
