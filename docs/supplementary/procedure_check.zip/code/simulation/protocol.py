"""Separate, auditable protocol revision; the original pilot runner is unchanged.

Independent uniform draws implement the stated per-ticket probabilities. They are
an explicit reconstruction, not a verified copy of the original randomization code.
"""

import copy
import json
import math
import random

from simulation.game import computer_allocation, winning_household
from simulation.treatments import TREATMENTS, tasks_in

PROTOCOL_VERSION = "independent_uniform_v2"


class ProtocolError(ValueError):
    """A failed or incomplete participant, including its complete partial record."""

    def __init__(self, message, record):
        super().__init__(message)
        record["status"] = "failed"
        record["error"] = message
        self.record = record


def _allocation(value):
    return (isinstance(value, dict) and set(value) == {"A", "B"}
            and all(type(v) is int and 0 <= v <= 10 for v in value.values())
            and sum(value.values()) == 10)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _parse(text, confirmation):
    value = json.loads(text, object_pairs_hook=_unique_object)
    if not confirmation and _allocation(value):
        return value
    if confirmation and isinstance(value, dict):
        if set(value) == {"confirm"} and value["confirm"] is True:
            return value
        if set(value) == {"confirm", "A", "B"} and value["confirm"] is False:
            if _allocation({key: value[key] for key in ("A", "B")}):
                return value
    raise ValueError("reply does not match the requested JSON schema")


def _probabilities(this_round, choice, conditional):
    denominator = 10 if conditional else 20
    a = choice["A"] if conditional else choice["A"] + this_round["computer"]["A"]
    b = denominator - a
    return (f"Household A has a {a}/{denominator} chance ({100 * a // denominator}%) "
            f"of winning. Household B has a {b}/{denominator} chance "
            f"({100 * b // denominator}%) of winning.")


def run_player(treatment, prompts, seed, get_reply, max_confirmations=12, max_attempts=3):
    """Run one participant; callback receives messages and returns an LLM.chat dict.

    Allocation proposals and confirmation edits are retained separately. Only
    explicitly confirmed choices enter the compatible initial/revision fields.
    All requests, including invalid replies and provider failures, are retained.
    """
    if treatment not in TREATMENTS:
        raise ValueError(f"unknown treatment: {treatment}")
    if type(max_confirmations) is not int or max_confirmations < 1:
        raise ValueError("max_confirmations must be a positive integer")
    if type(max_attempts) is not int or max_attempts < 1:
        raise ValueError("max_attempts must be a positive integer")
    rng = random.Random(seed)
    rounds = {number: {"round": number, "task": task,
                      "computer": computer_allocation(number), "initial": None,
                      "revision": None, "draw": None, "winner": None}
              for number, task in enumerate(tasks_in(treatment), 1)}
    record = {"treatment": treatment, "seed": seed, "rounds": rounds,
              "protocol_version": PROTOCOL_VERSION,
              "prompt_version": prompts.PROMPT_VERSION,
              "draw_policy": "independent_uniform_1_to_20",
              "randomization_note": "Stated reconstruction; original randomization code unverified.",
              "status": "running", "payment": None, "reversals": 0,
              "cost": 0.0, "cost_unknown_requests": 0,
              "max_confirmations": max_confirmations, "max_attempts": max_attempts,
              "messages": [], "unsent": [], "proposals": [], "confirmations": [],
              "events": [], "requests": []}

    def event(kind, **details):
        record["events"].append({"index": len(record["events"]), "kind": kind, **details})

    def message(role, text, round_number=None, phase=None):
        index = len(record["messages"])
        record["messages"].append({"role": role, "content": text})
        if role == "user":
            record["unsent"].append(text)
        event("message", message_index=index, round=round_number, phase=phase)

    def values(this_round, choice=None, conditional=False):
        choice = choice or this_round["initial"] or {}
        draw = this_round["draw"] or {}
        return {"round": this_round["round"],
                "computer_a": this_round["computer"]["A"],
                "computer_b": this_round["computer"]["B"],
                "choice_a": choice.get("A"), "choice_b": choice.get("B"),
                "group": draw.get("group"), "ticket": draw.get("ticket"),
                "household": this_round["winner"],
                "probabilities": _probabilities(this_round, choice, conditional) if choice else ""}

    def information(template, this_round):
        message("user", template.format(**values(this_round)), this_round["round"], "information")

    def ask(question, this_round, phase, confirmation=False):
        response_format = prompts.CONFIRMATION_FORMAT if confirmation else prompts.ALLOCATION_FORMAT
        number = this_round["round"]
        message("user", question + "\n\n" + response_format, number, phase)
        for attempt in range(1, max_attempts + 1):
            request = {"index": len(record["requests"]), "round": number,
                       "phase": phase, "attempt": attempt,
                       "messages": copy.deepcopy(record["messages"]),
                       "reply": None, "parsed": None, "error": None}
            record["requests"].append(request)
            record["unsent"] = []
            try:
                reply = get_reply(copy.deepcopy(request["messages"]))
            except Exception as error:
                # Provider exceptions may contain account details; retain their class.
                request["error"] = f"provider error: {type(error).__name__}"
                record["cost_unknown_requests"] += 1
                event("request_failed", request_index=request["index"], round=number, phase=phase)
                if attempt == max_attempts:
                    raise ProtocolError(f"request attempts exhausted in round {number}, {phase}", record) from error
                continue
            request["reply"] = copy.deepcopy(reply)
            cost = reply.get("cost") if isinstance(reply, dict) else None
            if type(cost) in (int, float) and math.isfinite(cost) and cost >= 0:
                record["cost"] += cost
            else:
                record["cost_unknown_requests"] += 1
            text = reply.get("text") if isinstance(reply, dict) else None
            if isinstance(text, str):
                message("assistant", text, number, phase)
            try:
                if not isinstance(text, str):
                    raise ValueError("provider reply has no text string")
                parsed = _parse(text, confirmation)
            except (ValueError, TypeError) as error:
                request["error"] = str(error)
                event("invalid_reply", request_index=request["index"], round=number, phase=phase)
                if attempt == max_attempts:
                    raise ProtocolError(f"invalid replies exhausted attempts in round {number}, {phase}", record) from error
                correction = f"Round {number}. " + prompts.FORMAT_CORRECTION + "\n\n" + response_format
                message("user", correction, number, phase)
                continue
            request["parsed"] = copy.deepcopy(parsed)
            event("reply_accepted", request_index=request["index"], round=number, phase=phase)
            return parsed, request["index"]
        raise ProtocolError("request loop ended without a valid reply", record)

    def collect(this_round, stage):
        number = this_round["round"]
        conditional = stage == "revision" or this_round["task"] == "P"
        template = prompts.REVISION if stage == "revision" else prompts.ALLOCATION
        question = template.format(**values(this_round, conditional=conditional))
        candidate, request_index = ask(question, this_round, f"{stage}_allocation")
        record["proposals"].append({"round": number, "stage": stage,
                                    "request_index": request_index, "allocation": dict(candidate)})
        for _ in range(max_confirmations):
            question = prompts.CONFIRMATION.format(**values(this_round, candidate, conditional))
            response, request_index = ask(question, this_round, f"{stage}_confirmation", True)
            record["confirmations"].append({"round": number, "stage": stage,
                                            "request_index": request_index,
                                            "candidate": dict(candidate), "response": dict(response)})
            if response["confirm"]:
                this_round[stage] = dict(candidate)
                event("choice_confirmed", round=number, stage=stage,
                      request_index=request_index, allocation=dict(candidate))
                return
            candidate = {key: response[key] for key in ("A", "B")}
            record["proposals"].append({"round": number, "stage": stage,
                                        "request_index": request_index, "allocation": dict(candidate)})
        raise ProtocolError(f"confirmation limit reached in round {number}, {stage}", record)

    def draw(this_round):
        ticket = rng.randint(1, 20)
        this_round["draw"] = {"group": "participant" if ticket <= 10 else "computer", "ticket": ticket}
        event("draw", round=this_round["round"], draw=dict(this_round["draw"]))

    def reveal(this_round):
        template = prompts.GROUP_PARTICIPANT if this_round["draw"]["group"] == "participant" else prompts.GROUP_COMPUTER
        information(template, this_round)

    def resolve(this_round, template):
        allocation = this_round["revision"] or this_round["initial"]
        this_round["winner"] = winning_household(this_round["draw"], this_round["computer"], allocation)
        information(template, this_round)

    try:
        if prompts.SYSTEM:
            message("system", prompts.SYSTEM)
        message("user", prompts.INSTRUCTIONS)
        for this_round in rounds.values():
            information(prompts.ROUND_START, this_round)
            if this_round["task"] == "P":
                draw(this_round)
                reveal(this_round)
                if this_round["draw"]["group"] == "participant":
                    collect(this_round, "initial")
                resolve(this_round, prompts.OUTCOME_P)
            else:
                collect(this_round, "initial")
                draw(this_round)
                if this_round["task"] == "A":
                    resolve(this_round, prompts.OUTCOME_A)
        # No revision opportunity is disclosed until all four AR initial choices are confirmed.
        for this_round in rounds.values():
            if this_round["task"] != "AR":
                continue
            reveal(this_round)
            if this_round["draw"]["group"] == "participant":
                collect(this_round, "revision")
            resolve(this_round, prompts.OUTCOME_A)
        payment_round = rng.choice(list(rounds))
        record["payment"] = {"round": payment_round, "household": rounds[payment_round]["winner"],
                             "hypothetical": True}
        record["reversals"] = sum(r["revision"] is not None and r["revision"] != r["initial"]
                                  for r in rounds.values())
        record["status"] = "completed"
        event("completed", payment=dict(record["payment"]))
        return record
    except ProtocolError:
        raise
    except Exception as error:
        raise ProtocolError(f"protocol error: {type(error).__name__}: {error}", record) from error
