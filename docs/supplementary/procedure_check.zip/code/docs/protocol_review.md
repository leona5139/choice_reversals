# Procedure review and execution status

This review uses the Project C Milestone 1 handout, Andreoni et al. (2020), Section III and Tables 2-3, and its published Appendix C. The DOI is https://doi.org/10.1086/705549 . The reviewed paper and supplement are evidence sources; they are not modified by this package. The handout lists tasks and deliverables. A separate point-by-point scoring rubric was not available for this review.

## Evidence status

The original `pilot_1` contains 80 actual model participant records and 713 accepted replies. The original findings and figures refer to that version. Its saved data, original prompt and original runner are preserved.

The separately implemented `prompt_b` procedure has passed offline software checks. These tests are scripted controls, not model behavior. Its `pilot_2` format/execution preflight ended with 10 completed participants and six failed participants after repeated fenced-JSON replies. Saved completed/failed participant records contain 22 invalid-format replies and one failed provider call. The logs separately retain an interrupted ninth-participant attempt: 18 returned events, one `GeminiRequestError` failure, and one started callback whose provider outcome and charge are unknown. `output/results/pilot_2/execution_notes.json` records this handling. Original events, reservations and source versions are retained. This preflight is not a completed 16-participant study and is not pooled with either other run.

The corrected model pilot, `pilot_3`, is **complete and validated**, with all 16 planned participants and 128 round records. Its fixed plan used `gemini-3.1-flash-lite` and `gemini-3.5-flash-lite`, two participants per model and condition, all four conditions, temperature 1.0, and `MINIMAL` thinking. Four workers maintained separate participant conversations. Provider `application/json` response mode applied uniformly to both models; the economic procedure and prompt were unchanged from the preflight. Returned model-version fields contain those same model IDs, rather than dated version identifiers.

The 322 recorded requests produced 301 valid returned responses and 21 request errors, with no invalid-format replies and no failed participant attempts. All 21 errors were recorded as `GeminiRequestError` for Gemini 3.5 Flash-Lite; the logs do not establish their specific network/provider cause. There were 14 post-reveal changes among 40 eligible AR opportunities (35%), plus one initial confirmation edit counted separately. These observations are separate from the original diagnostic pilot and the retained preflight. The cumulative reservation was $1.69580455; returned usage gives an estimated $0.17646025. Charges for the 21 unreturned requests remain unknown, so neither figure is a final bill.

## Source and implementation checks

| Requirement | Primary source | Corrected implementation |
|---|---|---|
| Twenty tickets and a $10 allocation task | Main paper p. 1683; Figure C.16 | Same ticket groups and amount in prompt_b; hypothetical implementation stated explicitly |
| One uniformly selected payment round | Main paper p. 1687; Figures C.16-C.17 | One of eight round indices selected uniformly after all decisions |
| Four condition sequences | Table 2, p. 1687 | AAAA, PPPP, AAPP, PPAA, each followed by four AR rounds |
| Fixed computer allocations | Table 3, p. 1688 | Tickets to A are 7, 2, 10, 1, 8, 3, 9, 0 |
| Computer allocation shown at each round's start | Main paper p. 1687 | Shown even when a P round is won by the computer |
| Review and confirmation until accepted | Main paper pp. 1683-1684; Figure C.21 | A proposed allocation is displayed with probabilities; any change is redisplayed until explicitly confirmed |
| Conditional within-group probability | Figures C.20 and C.22 | Each participant ticket has probability 1/10 after a participant-group reveal; computer tickets cannot win |
| Household probabilities | Figure C.21; supplement revision interface | Total tickets divided by 20 before the draw; participant tickets divided by 10 after own-group selection |
| Ordinary A feedback | Figures C.16-C.17 | Winning group is shown; exact ticket is hidden. The original A feedback was supported, so it was retained |
| P outcome | Main paper p. 1683 | Exact ticket is revealed after confirmation; ticket mapping and winning household make it interpretable |
| Surprise timing | Main paper pp. 1684 and 1687 | All four initial AR choices are confirmed before any AR winning group is revealed; later revision is not announced in advance |
| Reversal measurement | Main paper Section IV.C | Compare confirmed initial and confirmed post-reveal choices only among eligible AR rounds |

The source instructions establish the per-round random lottery. The exact cross-round scheduling code of the original human study was unavailable. The revised code declares independent uniform draws. This removes the earlier fixed two-wins quota and keeps each announced 1/20 probability valid conditional on prior observed outcomes. Independence is a stated reconstruction, not a claim about recovered original source code.

## Remaining adaptations

Text replaces recipient photographs, household-type descriptions and timed breaks. Households A and B remain unidentified and have no unequal-deservingness information. The $10 amount is retained as a hypothetical task; no donation or participant payment occurs. Counts replace individual ticket buttons and assign consecutive numbered tickets to A, then the remainder to B. These are stated interface and incentive adaptations, not claims of an identical human setting.

The model is asked for a JSON allocation and an explicit JSON confirmation. Invalid formatting receives a neutral format reminder. After three invalid/provider attempts or twelve unconfirmed review turns, the participant is marked incomplete instead of silently accepting a draft. All ordinary failures and any later retries remain recorded. The callback journal also preserves inputs and returned replies across interruptions. The default Gemini REST client has no hidden SDK retries. Initial confirmation edits are distinct from post-reveal reversals.

## Milestone 1 handout coverage

This table maps the handout's tasks to evidence. It is not a point-by-point grading rubric. The Milestone 1 handout does not specify a page limit; its one-page Milestone 2 limit and five-page final-report limit concern different submissions.

| Handout task or deliverable | Evidence in this package |
|---|---|
| Implement all four Table 2 conditions and explain procedure adaptations | `simulation/protocol.py`, `prompt/prompt_b.py`, the source checks above, and the report's procedure discussion |
| Preserve payoffs, probabilities and information structure | Twenty-ticket, conditional-probability, confirmation and disclosure checks above; hypothetical incentives and independent draws explicitly identified as adaptations |
| Use neutral prompts, consistent response formats, fresh participant conversations and each participant's own history | `prompt/prompt_b.py`, `simulation/protocol.py`, and saved participant histories |
| Run a small pilot with at least two models | Validated 16-participant, two-model `output/results/pilot_3`; original four-model diagnostic pilot and incomplete preflight retained separately |
| Give three or four actual responses and discuss errors, irregularities and comparison with humans | Four recorded corrected-pilot examples in `output/results/pilot_3/response_examples.txt`, validated counts in `summary.json`, and the report's response and human-comparison discussion |
| Supply working code, prompt templates and sample CSV/JSON results | `simulation/`, `prompt/`, `analysis/`, and separate original, preflight and corrected datasets in `output/results/` |
| State the division of work | Contribution paragraph in `docs/writeups/milestone1.tex`, based on documented contributions |
| Submit the group-number PDF and code/data | Compiled `group4.pdf` and the submission archive; Canvas submission is a separate action |

## Verification and execution

From the repository root, the following checks use no provider access and need only Python 3.11 or later, with no `uv` installation.

```sh
python analysis/check_pilot_replies.py
python -m analysis.check_corrected_pilot output/results/pilot_3
python -m unittest discover -s tests -v
python -m simulation.run_corrected --dry-run --run-name pilot_3 --workers 4 --requests-per-minute 60
```

The behavioral tests cover all four conditions, all 20 possible ticket outcomes for each allowed allocation, repeated confirmation and information disclosure. The corrected-run validator replays recorded inputs/replies and checks source hashes, the fixed participant roster, confirmed choices, draws, payment, failed attempts and cost information. It rejects incomplete rosters, duplicate IDs, altered metadata, missing confirmations and relabelled scripted replies.

The original checker still verifies all original counts and the four printed real examples. It is intentionally not applied to the revised protocol's confirmation messages.

For the real pilot, set `GEMINI_API_KEY` in the process environment. A local `.env` file is optional and is loaded only when `python-dotenv` is installed. No SDK is required for the default Gemini runner. The actual fixed run uses:

```sh
python -m simulation.run_corrected --run-name pilot_3 --workers 4 --requests-per-minute 60
```

The runner saves each completed participant immediately. A participant interrupted before saving a completed record restarts with the same ID and seed, in a new conversation. Completed participants within that plan are skipped. Partial conversations and reservations are retained and reported separately. Resume with the same four-worker setting and rate, which are recorded in the manifest. Do not run the changed client over the retained `pilot_2` manifest. The optional checkpoint wrapper supports a separately named one-worker plan only; it cannot resume this four-worker `pilot_3`.

The standard-library client sends requests to `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`, using the `X-goog-api-key` authentication header. Keys and authentication headers are not stored. Each network request has a 60-second timeout and a 1,024-token generated-output limit, including thinking tokens. `MINIMAL` thinking does not mean thinking is disabled. There are no hidden SDK retries. A persistent shared ledger reserves conservatively before each request and limits this run to 500 request reservations and $2 in cumulative reservations. Failed and interrupted calls retain their reservations. The limit applies to estimated reservations and does not guarantee the provider's final bill.

Published standard Gemini Developer API prices checked on November 5, 2026 are $0.25 per million input tokens and $1.50 per million output tokens for Gemini 3.1 Flash-Lite, and $0.30 input and $2.50 output for Gemini 3.5 Flash-Lite. Output prices include thinking tokens. Full conversation history sent again counts as input. Sources: https://ai.google.dev/gemini-api/docs/pricing and https://firebase.google.com/docs/ai-logic/thinking . Saved provider usage supports a cost estimate, not an account-wide charge total.

The output belongs in `output/results/pilot_3`. Do not combine it with `pilot_1` or `pilot_2`. A completed verified run has 16 participants. On a recorded failure, inspect it and use the explicit `--retry-failed` option; do not remove inconvenient choices or selectively rerun completed participants. Retain the worker count and rate because both are part of the recorded plan.

```sh
python -m simulation.run_corrected --run-name pilot_3 --workers 4 --requests-per-minute 60 --retry-failed
python -m analysis.check_corrected_pilot output/results/pilot_3
```

The second command makes no API calls. It writes checked counts, a per-round CSV and recorded response examples. Original-pilot analysis still uses the project's existing dependencies: `uv sync --frozen`, then `uv run python -m analysis.run_analysis.pilot_1`.

The preflight's client and runner are archived at `simulation/archive/gemini_bounded_pilot2.py` and `simulation/archive/run_corrected_pilot2.py`. Its incomplete evidence can be checked without any model calls:

```sh
python -m analysis.check_corrected_pilot output/results/pilot_2 --allow-incomplete
```

This uses the archived source versions and writes `partial_summary.json` and `partial_summary.md`. Allowing an incomplete audit does not certify completion; the default validator still requires the entire fixed roster.

## Reporting and evidence separation

Report `pilot_3` as the corrected study using its validated counts, returned model IDs, denominators and examples. Retain the original `pilot_1` as diagnostic evidence and `pilot_2` as the format/execution preflight, including its failures and interrupted attempt. Keep the three datasets separate and distinguish confirmation edits from post-reveal reversals. The report source and compiled PDF must describe the same completed evidence.

The report's contribution statement records documented work, not equal hours or identical task counts. Canvas submission remains a separate action. These checks support the submission but do not guarantee a grade.
