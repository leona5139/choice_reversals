# Choice reversals

The repository preserves three separate runs. `pilot_1` is the original diagnostic pilot with 80 model participants and 713 accepted replies using `prompt_a`. `pilot_2` is a retained format/execution preflight of the corrected procedure, with 10 completed participants and six failed participants. `pilot_3` is the **completed, validated 16-participant corrected pilot**, using provider JSON response mode uniformly for both models and four workers with independent participant conversations. These runs are not pooled.

The corrected pilot contains 128 round records, 301 valid returned responses and 21 request errors across 322 attempts. All participants completed; no returned reply violated the required format. The errors were recorded as `GeminiRequestError` for Gemini 3.5 Flash-Lite; their specific network/provider cause was not recorded. Among 40 eligible AR opportunities, 14 confirmed allocations changed after the reveal. One initial confirmation edit is counted separately.

## Check the submitted evidence without API access

Run from the repository folder with Python 3.11 or later. These checks and the default corrected Gemini runner use the Python standard library; they do not require `uv` or an SDK.

```sh
python analysis/check_pilot_replies.py
python -m analysis.check_corrected_pilot output/results/pilot_3
python -m unittest discover -s tests -v
python -m simulation.run_corrected --dry-run --run-name pilot_3 --workers 4 --requests-per-minute 60
```

The last command uses scripted controls and writes only under `output/validation/independent_uniform_v2/pilot_3`. It makes no API calls. Those records are not model observations. The test suite checks the lottery probabilities, ticket outcomes, all four conditions, confirmation loops, information timing and failure handling.

## Run the corrected pilot with the group's API access

Set `GEMINI_API_KEY` in the process environment. A local `.env` file is also supported if the optional `python-dotenv` package is installed; `.env.example` gives the variable name. Do not upload `.env` or an API key. The fixed plan uses `gemini-3.1-flash-lite` and `gemini-3.5-flash-lite`, with two participants per model and condition, temperature 1.0, and all four conditions. This is a fixed plan of 16 participants. Thinking is set to `MINIMAL`. The provider's `application/json` response mode applies to both models; the economic procedure and prompt are unchanged from the preflight.

```sh
python -m simulation.run_corrected --run-name pilot_3 --workers 4 --requests-per-minute 60
```

This command runs the fixed roster with four independent workers. Each completed participant is saved immediately. Worker count and rate are part of the recorded plan: resume with the same arguments. An interrupted participant without a completed record restarts with the same planned ID and seed, in a fresh conversation. Earlier partial calls remain in the journal and are accounted for separately from completed participant observations.

Real runs use the provider account and may consume its quota or credits. The program checks for credentials before any model calls. It writes its plan and source hashes before running, keeps a separate conversation for every participant, and saves confirmed choices and exact input/reply histories under `output/results/pilot_3`.

The default runner sends direct Gemini REST requests with a 60-second network timeout, at most 1,024 generated tokens per response, including thinking tokens, and no hidden SDK retries. A persistent shared ledger limits the run to 500 request reservations and $2 in cumulative conservative cost reservations. Reservations are retained after errors and interruptions; the limit applies to estimated reservations and does not guarantee the provider's final bill. Authentication headers and keys are not stored. The procedure permits at most three attempts per question and twelve unconfirmed review turns; unresolved failures mark the participant incomplete.

The final validator requires all 16 completed participants and exits nonzero if the fixed plan remains incomplete or its records fail validation. Earlier failures remain saved. Rerunning skips validated completions; use `--retry-failed` to retry the remaining failed participants while retaining their earlier attempts. Do not change the roster based on the choices or erase failed attempts.

```sh
python -m simulation.run_corrected --run-name pilot_3 --workers 4 --requests-per-minute 60 --retry-failed
python -m analysis.check_corrected_pilot output/results/pilot_3
```

Retain `--workers 4 --requests-per-minute 60` for this recorded plan. Its validation outputs are `summary.json`, `summary.md`, `rounds.csv` and four recorded examples in `response_examples.txt`. Use these checked counts and examples for reporting; keep the corrected pilot separate from the original pilot and the preflight.

`simulation.run_checkpointed` is available for a separately named one-worker plan. It cannot resume `pilot_3`, whose manifest fixes four workers. To use that wrapper for a new study, choose a new `--run-name` and `--workers 1`; each invocation saves and checks one participant before stopping.

Use a new `--run-name` for a changed plan. A changed source version or sample plan cannot resume over the old run. Custom model sets require at least two distinct `--model provider:model` values. The bounded Gemini path accepts only models with verified prices in `GEMINI_RATES`; the optional existing SDK path for other supported provider combinations requires the project's installed dependencies and is outside the documented run's REST spending controls.

The callback journal preserves inputs and returned replies as they occur. Usage-based cost estimates are not a billing total. An interrupted callback may have an unknown outcome and must be checked in the journal.

## Retained format and execution preflight

`output/results/pilot_2` retains 10 completed participants and six participants who failed after three fenced-JSON replies. Its saved completed/failed participant records contain 22 invalid-format replies and one failed provider call. A separate interrupted attempt during the ninth participant contains 18 returned calls, one `GeminiRequestError`, and one started call with an unknown outcome. `execution_notes.json` records the interruption. No saved completed participant was rerun within that plan, and earlier events and reservations were retained. The separately named `pilot_3` applies JSON response mode uniformly to a new full roster.

The preflight's exact client and runner are preserved in `simulation/archive/gemini_bounded_pilot2.py` and `simulation/archive/run_corrected_pilot2.py`. Audit its retained partial evidence without API access:

```sh
python -m analysis.check_corrected_pilot output/results/pilot_2 --allow-incomplete
```

This writes `partial_summary.json` and `partial_summary.md`, checks the archived source versions, and does not certify a completed 16-participant pilot. The default validator remains strict about completeness.

## Original pilot

```sh
uv sync --frozen
uv run python -m analysis.run_analysis.pilot_1
```

This reproduces the original pilot's analysis. `main.py` is the original API runner; it is retained to document that version and is not the corrected runner. Avoid rerunning it when checking saved evidence.

See `docs/protocol_review.md` for the source-based procedure checks and `analysis/README.md` for the original analysis outputs. The report source is `docs/writeups/milestone1.tex`; compile it twice with XeLaTeX or use its existing Overleaf-compatible setup.
