Revised pilot observations

Validation status: verified_complete.
Evidence kind: model_pilot.

Completed participants: 16 of 16.
Eligible post-reveal choices: 40.
Changes between confirmed initial and confirmed post-reveal choices: 14.
Initial confirmation edits are counted separately: 1.
Recorded failed participant attempts, including later successful retries: 0.
Application requests in completed participant records: 322.
Application requests in normally failed participant records: 0.
Recorded application requests across completed and failed attempts: 322.
Provider-reported known cost: 0.000000; requests without a known cost: 322.
Direct REST calls use no SDK-internal retry loop.

The sample plan and exact source hashes are in manifest.json. Raw replies and exact input histories are retained in players.jsonl and failures.jsonl.
The original pilot is a separate dataset and is not combined with these counts.

| Model | Condition | Participants | Eligible revisions | Changes |
|---|---|---:|---:|---:|
| gemini/gemini-3.1-flash-lite | 4A_4AR | 2 | 5 | 0 |
| gemini/gemini-3.1-flash-lite | 4P_4AR | 2 | 7 | 3 |
| gemini/gemini-3.1-flash-lite | 2A2P_4AR | 2 | 2 | 0 |
| gemini/gemini-3.1-flash-lite | 2P2A_4AR | 2 | 6 | 6 |
| gemini/gemini-3.5-flash-lite | 4A_4AR | 2 | 5 | 2 |
| gemini/gemini-3.5-flash-lite | 4P_4AR | 2 | 7 | 2 |
| gemini/gemini-3.5-flash-lite | 2A2P_4AR | 2 | 2 | 1 |
| gemini/gemini-3.5-flash-lite | 2P2A_4AR | 2 | 6 | 0 |

Reversal rates use eligible post-reveal opportunities. Decisions within a participant share history and are not independent observations.

Reserved HTTP attempts: 322.
Cumulative conservative reservation: $1.695805.
Estimate from returned usage counts and declared rates: $0.176460.
Reservations without a returned provider response: 21.
Returned responses outside normal participant records: 0.
Journal callbacks across every attempt: 322 started, 301 returned, 21 failed, 0 without a terminal event.
Participant attempts retained only in the journal: 0.
Reservations and usage estimates are separate from provider billing. Interrupted or unreturned attempts can have unknown charges.
