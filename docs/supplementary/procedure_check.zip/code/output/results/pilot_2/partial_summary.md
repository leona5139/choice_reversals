Revised pilot observations

Validation status: verified_partial.
Evidence kind: model_pilot.

The fixed sample plan is incomplete. The counts below describe completed participants only and do not establish a complete, balanced pilot. Failed and journal-only attempts remain separate, with their full raw evidence retained.

Completed participants: 10 of 16.
Eligible post-reveal choices: 22.
Changes between confirmed initial and confirmed post-reveal choices: 13.
Initial confirmation edits are counted separately: 2.
Recorded failed participant attempts, including later successful retries: 6.
Application requests in completed participant records: 201.
Application requests in normally failed participant records: 18.
Recorded application requests across completed and failed attempts: 219.
Provider-reported known cost: 0.000000; requests without a known cost: 219.
Direct REST calls use no SDK-internal retry loop.

The sample plan and exact source hashes are in manifest.json. Raw replies and exact input histories are retained in players.jsonl and failures.jsonl.
The original pilot is a separate dataset and is not combined with these counts.

| Model | Condition | Participants | Eligible revisions | Changes |
|---|---|---:|---:|---:|
| gemini/gemini-3.1-flash-lite | 4A_4AR | 2 | 6 | 6 |
| gemini/gemini-3.1-flash-lite | 4P_4AR | 2 | 3 | 0 |
| gemini/gemini-3.1-flash-lite | 2A2P_4AR | 2 | 4 | 2 |
| gemini/gemini-3.1-flash-lite | 2P2A_4AR | 2 | 5 | 5 |
| gemini/gemini-3.5-flash-lite | 4A_4AR | 1 | 2 | 0 |
| gemini/gemini-3.5-flash-lite | 4P_4AR | 0 | 0 | 0 |
| gemini/gemini-3.5-flash-lite | 2A2P_4AR | 1 | 2 | 0 |
| gemini/gemini-3.5-flash-lite | 2P2A_4AR | 0 | 0 | 0 |

Reversal rates use eligible post-reveal opportunities. Decisions within a participant share history and are not independent observations.

Reserved HTTP attempts: 239.
Cumulative conservative reservation: $1.135155.
Estimate from returned usage counts and declared rates: $0.120631.
Reservations without a returned provider response: 3.
Returned responses outside normal participant records: 18.
Journal callbacks across every attempt: 239 started, 236 returned, 2 failed, 1 without a terminal event.
Participant attempts retained only in the journal: 1.
Reservations and usage estimates are separate from provider billing. Interrupted or unreturned attempts can have unknown charges.
Journal-only attempt ae098ae2ea7a4d08ae264a6f79db0c7d for 4A_4AR|gemini|gemini-3.5-flash-lite|t=1.0|prompt_b|0: 20 callbacks started, 18 returned, 1 failed, 1 unfinished. It is not included in behavioral results.
