"""Text prompts for the separately recorded protocol revision.

The monetary task is hypothetical. The report should identify this adaptation.
Ticket counts replace individual ticket buttons; the mapping is stated explicitly.
"""

PROMPT_VERSION = "prompt_b"

SYSTEM = "Follow the instructions for each round and make your own allocation decisions."

INSTRUCTIONS = """Consider a donation allocation task involving households in Kenya.
There are eight rounds. Each round concerns two different households, called Household A and Household B. No individual information distinguishes them or indicates that one is more deserving.

You allocate tickets 1-10 between the two households. The computer allocates tickets 11-20, and its allocation cannot be changed. You will see the computer's allocation at the start of each round.

One ticket is drawn uniformly from tickets 1-20 in each round. Each ticket has probability 1/20 of being selected. Draws in different rounds are independent. The household assigned the selected ticket wins that round.

Within each group of ten tickets, the lowest-numbered tickets are assigned to Household A and the remaining tickets to Household B. For example, assigning three of your tickets to A assigns tickets 1, 2 and 3 to A. The same rule applies to the computer's group starting at ticket 11.

One of the eight rounds is selected uniformly at the end. In this hypothetical task, its winning household would receive $10. No real donation is made. Make each decision as one that could determine the selected round's result."""

ROUND_START = """Round {round}. The computer has assigned {computer_a} of its ten tickets to Household A and {computer_b} to Household B. Its allocation cannot be changed."""

ALLOCATION = """Round {round}. Assign your ten tickets between Household A and Household B using the information available for this round."""

GROUP_PARTICIPANT = """Round {round}. The winning ticket is one of your tickets 1-10. Its number has not been revealed. Each of your ten tickets has probability 1/10 of being the winning ticket. None of the computer's tickets can win."""

GROUP_COMPUTER = """Round {round}. The winning ticket is one of the computer's tickets 11-20. Its number has not been revealed. Each of those ten tickets has probability 1/10 of being the winning ticket. None of your tickets can win. The computer's fixed allocation determines the winner, so you have no allocation decision for this round."""

REVISION = """Round {round}. Your earlier confirmed allocation assigned {choice_a} tickets to Household A and {choice_b} to Household B. The computer assigned {computer_a} to A and {computer_b} to B. You now know that one of your tickets is the winning ticket, but its number remains unknown.

Under your earlier allocation, {probabilities}

Submit your allocation again. You may keep the same allocation or change it. Submit the ticket counts even if you keep them unchanged."""

CONFIRMATION = """Round {round}. Review the allocation you just submitted. You assigned {choice_a} tickets to Household A and {choice_b} to Household B. The computer's fixed allocation is {computer_a} to A and {computer_b} to B.

{probabilities}

Confirm this allocation or submit a different allocation for review."""

OUTCOME_A = """Round {round} is complete. The winning ticket belongs to the {group} group. The ticket number is not revealed."""

OUTCOME_P = """Round {round} is complete. The winning ticket is ticket {ticket}, in the {group} group, assigned to Household {household}. That household wins this round."""

ALLOCATION_FORMAT = 'Respond with one JSON object and nothing else, using exactly the keys "A" and "B". Each value must be an integer from 0 to 10, and the two values must sum to 10.'

CONFIRMATION_FORMAT = 'To confirm, respond with exactly {"confirm": true}. To change your allocation, respond with one JSON object using exactly the keys "confirm", "A" and "B", with "confirm" set to false and integer ticket counts from 0 to 10 summing to 10. A changed allocation will be shown again for confirmation. Include no other text.'

FORMAT_CORRECTION = "Your last reply did not match the required response format. Please answer the same question using the required format below."
