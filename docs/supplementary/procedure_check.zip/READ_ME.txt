Supplementary procedure check for group review

This archive preserves a separately run procedure version and its evidence. It does not replace the original pilot's prompt_a, simulation/run.py, saved observations or figures in the main repository. The main Milestone 1 report continues to use the original 80-player pilot as its primary analysis. The extra 16-player results are reported separately and are not pooled.

Contents
code/ holds the executable source snapshot, including isolated newer files, exact source hashes, original data, retained partial pilot_2 and completed pilot_3. Its README and docs/protocol_review.md explain reproduction and the adaptations. The original preflight runtime source is in simulation/archive. All 24 offline tests pass. The 16-player pilot validator passes with all responses, confirmations and callbacks accounted for. Original results also verify. There are no credentials in this archive.

Completed pilot_3
Two models, four conditions, two participants per cell, 16 completed players, 128 rounds. Temperature 1.0, MINIMAL thinking, provider JSON mode. 322 requests comprise 301 valid returned responses and 21 request failures recovered by retries. No invalid-format replies or unfinished callbacks remain. There are 14 post-reveal changes among 40 eligible opportunities. A separate initial-confirmation edit is excluded from reversals. The pure-A condition has 2/10 reversals. Results are descriptive and do not identify a causal effect of the interface changes.

The human appendix supports group-only A feedback. Confirmation and its probability display were deliberately omitted in the original group pilot. The additional version includes them for comparison. The original fixed quota gives marginal one-half probabilities but dependence within each block. Independent uniform draws in this separate version are a stated reconstruction; the original human cross-round generator is unavailable. Hypothetical payment and text interface adaptations remain explicit.

The main group4.pdf is the sole report proposed for Canvas submission. This archive contains supporting source and evidence, not a competing submission report.

Offline verification from the extracted code directory
python -m unittest discover -s tests -v
python analysis/check_pilot_replies.py
python -m analysis.check_corrected_pilot output/results/pilot_3
python -m analysis.check_corrected_pilot output/results/pilot_2 --allow-incomplete

No API call is required to verify saved results. Do not put keys in GitHub or chats.
